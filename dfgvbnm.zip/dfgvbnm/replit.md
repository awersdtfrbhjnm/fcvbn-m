# Overview

This is a full-stack web application that provides an AI-powered chat interface for querying the Income Tax Act. The system comes pre-loaded with Income Tax Act content processed from PDF format, creating a searchable knowledge base. The application uses Google's Gemini AI to analyze user questions with advanced parsing logic, extract relevant keywords and entities, search through tax act content comprehensively, and generate accurate responses based solely on the pre-loaded Act content. The application features a modern React frontend with shadcn/ui components and an Express.js backend with in-memory storage for rapid prototyping.

## Recent Changes (January 2025)
- Added comprehensive PDF processing functionality for Income Tax Act content
- Implemented advanced user request parsing with intent detection and entity extraction  
- Enhanced search algorithm with keyword expansion and synonym matching
- Built request parser service that identifies query types (TDS, deductions, exemptions, etc.)
- Integrated PDF-to-text conversion with section extraction and validation
- Updated chat system to use enhanced parsing for more accurate responses
- Created admin upload system for complete Income Tax Act PDF (~350 sections)
- Built upload scripts and status checking tools for easy PDF integration
- System ready to replace sample content with full Act via simple upload process

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **UI Components**: shadcn/ui component library built on Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with CSS variables for theming and design consistency
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Backend Architecture
- **Runtime**: Node.js with Express.js framework using ES modules
- **Language**: TypeScript for type safety across the entire stack
- **API Design**: RESTful endpoints with structured JSON responses
- **Session Management**: Session-based chat conversations with unique session IDs
- **PDF Processing**: Advanced PDF parsing using pdf-parse library to extract and structure Income Tax Act content
- **Request Parsing**: Intelligent user query analysis with keyword extraction, intent detection, and entity recognition
- **Content Processing**: Text processing service for parsing and structuring tax act documents
- **Storage Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **File Upload**: Multer-based PDF upload system with validation and processing pipeline

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: 
  - Users table for authentication
  - Documents table for storing tax act content with structured sections
  - Chat messages table for conversation history with role-based messaging
  - Search results table for caching query results
- **Connection**: Neon Database serverless PostgreSQL for cloud hosting
- **Migrations**: Drizzle Kit for database schema management and migrations

## AI Integration
- **Provider**: Google Gemini AI (gemini-2.5-flash model) for natural language processing
- **Keyword Extraction**: AI-powered analysis to identify relevant tax concepts from user queries
- **Query Parsing**: Advanced request parsing with intent detection, entity extraction, and query type classification
- **Search Enhancement**: Multi-layered search using extracted keywords, section numbers, and synonyms
- **Response Generation**: Context-aware response generation using only retrieved Income Tax Act sections
- **Structured Output**: JSON schema validation for consistent AI responses
- **Source Attribution**: Automatic citation of relevant tax act sections with page numbers
- **Content Validation**: Ensures AI responses are based solely on uploaded Income Tax Act content

## External Dependencies

- **AI Service**: Google Gemini AI API for natural language processing and response generation
- **Database**: Neon Database (PostgreSQL) for data persistence and document storage
- **Development Tools**: Replit integration for cloud development environment
- **UI Framework**: Radix UI primitives for accessible component foundations
- **Build Tools**: Vite for frontend bundling and esbuild for backend compilation
- **Validation**: Zod for runtime type validation and schema enforcement
- **Authentication**: Session-based authentication with connect-pg-simple for PostgreSQL session storage