import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  User, 
  Users, 
  IndianRupee, 
  Building, 
  Package, 
  Plus, 
  Trash2, 
  TrendingUp, 
  CheckCircle, 
  AlertCircle,
  FileText,
  Lightbulb
} from "lucide-react";

const formSchema = z.object({
  taxpayerInfo: z.object({
    name: z.string().min(1, "Name is required"),
    pan: z.string().regex(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, "Invalid PAN format (e.g., ABCDE1234F)"),
    age: z.coerce.number().min(18, "Must be 18 or older").max(100, "Invalid age"),
  }),
  hasSpouse: z.boolean(),
  spouseInfo: z.object({
    name: z.string().optional(),
    age: z.coerce.number().optional(),
    hasIncome: z.boolean(),
    income: z.coerce.number().optional(),
  }).optional(),
  dependents: z.array(z.object({
    name: z.string().min(1, "Name is required"),
    age: z.coerce.number().min(0, "Invalid age"),
    relationship: z.string().min(1, "Relationship is required"),
  })),
  incomeSources: z.array(z.object({
    type: z.string().min(1, "Type is required"),
    amount: z.coerce.number().min(1, "Amount must be greater than 0"),
    details: z.string().optional(),
  })).min(1, "At least one income source is required"),
  expenses: z.array(z.object({
    type: z.string().min(1, "Type is required"),
    amount: z.coerce.number().min(0, "Amount must be positive"),
    isEligibleForDeduction: z.boolean(),
    details: z.string().optional(),
  })),
  assets: z.array(z.object({
    type: z.string().min(1, "Type is required"),
    purchaseValue: z.coerce.number().min(0, "Value must be positive"),
    currentValue: z.coerce.number().min(0, "Value must be positive"),
    depreciationRate: z.coerce.number().optional(),
    purchaseDate: z.string().min(1, "Purchase date is required"),
  })),
  businessDetails: z.object({
    businessType: z.string().optional(),
    revenue: z.coerce.number().optional(),
    hasAssets: z.boolean(),
    profitMargin: z.coerce.number().optional(),
  }).optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function TaxPlanningPage() {
  const { toast } = useToast();
  const [submittedProfileId, setSubmittedProfileId] = useState<string | null>(null);
  const [userId] = useState(() => `user-${Date.now()}`);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      taxpayerInfo: { name: "", pan: "", age: 30 },
      hasSpouse: false,
      spouseInfo: { name: "", age: 30, hasIncome: false, income: 0 },
      dependents: [],
      incomeSources: [{ type: "Salary", amount: 0, details: "" }],
      expenses: [],
      assets: [],
      businessDetails: { businessType: "", revenue: 0, hasAssets: false, profitMargin: 0 },
    },
  });

  const { fields: dependentFields, append: appendDependent, remove: removeDependent } = useFieldArray({
    control: form.control,
    name: "dependents",
  });

  const { fields: incomeFields, append: appendIncome, remove: removeIncome } = useFieldArray({
    control: form.control,
    name: "incomeSources",
  });

  const { fields: expenseFields, append: appendExpense, remove: removeExpense } = useFieldArray({
    control: form.control,
    name: "expenses",
  });

  const { fields: assetFields, append: appendAsset, remove: removeAsset } = useFieldArray({
    control: form.control,
    name: "assets",
  });

  const createProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/financial-profile", data);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Profile Created",
        description: "Your financial profile has been saved successfully. Tax planning mode is now active in chat!",
      });
      setSubmittedProfileId(data.profile.id);
      
      // Store profile info in localStorage for chat integration
      localStorage.setItem('tax-profile-id', data.profile.id);
      localStorage.setItem('tax-user-id', userId);
      
      queryClient.invalidateQueries({ queryKey: ["/api/tax-strategies", data.profile.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/followup-questions", data.profile.id] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create profile",
        variant: "destructive",
      });
    },
  });

  const { data: strategiesData } = useQuery<any[]>({
    queryKey: ["/api/tax-strategies", submittedProfileId],
    enabled: !!submittedProfileId,
  });

  const { data: questionsData } = useQuery<any[]>({
    queryKey: ["/api/followup-questions", submittedProfileId],
    enabled: !!submittedProfileId,
  });

  const onSubmit = (data: FormData) => {
    const hasBusinessIncome = data.incomeSources.some(s => 
      s.type.toLowerCase().includes("business")
    );

    const payload = {
      userId,
      taxpayerInfo: data.taxpayerInfo,
      spouseInfo: data.hasSpouse ? data.spouseInfo : null,
      dependents: data.dependents,
      incomeSources: data.incomeSources,
      expenses: data.expenses,
      assets: data.assets,
      businessDetails: hasBusinessIncome ? data.businessDetails : null,
    };

    createProfileMutation.mutate(payload);
  };

  const hasSpouse = form.watch("hasSpouse");
  const spouseHasIncome = form.watch("spouseInfo.hasIncome");
  const incomeSources = form.watch("incomeSources");
  const hasBusinessIncome = incomeSources?.some(s => 
    s.type.toLowerCase().includes("business")
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Tax Planning</h1>
          <p className="text-gray-600">Complete your financial profile to get personalized tax-saving strategies</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Card data-testid="card-taxpayer-info">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Taxpayer Information
                </CardTitle>
                <CardDescription>Your basic taxpayer details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="taxpayerInfo.name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="John Doe" data-testid="input-taxpayer-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="taxpayerInfo.pan"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>PAN Number</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="ABCDE1234F" data-testid="input-taxpayer-pan" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="taxpayerInfo.age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} placeholder="30" data-testid="input-taxpayer-age" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-spouse-info">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Spouse Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="hasSpouse"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-has-spouse"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>I have a spouse</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
                {hasSpouse && (
                  <>
                    <FormField
                      control={form.control}
                      name="spouseInfo.name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Spouse Name</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Jane Doe" data-testid="input-spouse-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="spouseInfo.age"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Spouse Age</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} placeholder="28" data-testid="input-spouse-age" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="spouseInfo.hasIncome"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-spouse-has-income"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Spouse has income</FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                    {spouseHasIncome && (
                      <FormField
                        control={form.control}
                        name="spouseInfo.income"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Spouse Annual Income (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} placeholder="500000" data-testid="input-spouse-income" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </>
                )}
              </CardContent>
            </Card>

            <Card data-testid="card-dependents">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Dependents
                </CardTitle>
                <CardDescription>Add family members who are financially dependent on you</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {dependentFields.map((field, index) => (
                  <div key={field.id} className="border p-4 rounded-lg space-y-4" data-testid={`dependent-${index}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Dependent {index + 1}</h4>
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        onClick={() => removeDependent(index)}
                        data-testid={`button-remove-dependent-${index}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name={`dependents.${index}.name`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Name" data-testid={`input-dependent-name-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`dependents.${index}.age`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Age</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} placeholder="Age" data-testid={`input-dependent-age-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`dependents.${index}.relationship`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Relationship</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Son/Daughter/Parent" data-testid={`input-dependent-relationship-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => appendDependent({ name: "", age: 0, relationship: "" })}
                  className="w-full"
                  data-testid="button-add-dependent"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Dependent
                </Button>
              </CardContent>
            </Card>

            <Card data-testid="card-income-sources">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <IndianRupee className="h-5 w-5" />
                  Income Sources
                </CardTitle>
                <CardDescription>List all your sources of income</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {incomeFields.map((field, index) => (
                  <div key={field.id} className="border p-4 rounded-lg space-y-4" data-testid={`income-source-${index}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Income Source {index + 1}</h4>
                      {index > 0 && (
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => removeIncome(index)}
                          data-testid={`button-remove-income-${index}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name={`incomeSources.${index}.type`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-income-type-${index}`}>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Salary">Salary</SelectItem>
                                <SelectItem value="Business">Business</SelectItem>
                                <SelectItem value="Capital Gains">Capital Gains</SelectItem>
                                <SelectItem value="Rental">Rental</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`incomeSources.${index}.amount`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} placeholder="500000" data-testid={`input-income-amount-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`incomeSources.${index}.details`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Details</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Additional info" data-testid={`input-income-details-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => appendIncome({ type: "", amount: 0, details: "" })}
                  className="w-full"
                  data-testid="button-add-income"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Income Source
                </Button>
              </CardContent>
            </Card>

            <Card data-testid="card-expenses">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Expenses & Deductions
                </CardTitle>
                <CardDescription>Track expenses that may qualify for tax deductions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {expenseFields.map((field, index) => (
                  <div key={field.id} className="border p-4 rounded-lg space-y-4" data-testid={`expense-${index}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Expense {index + 1}</h4>
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        onClick={() => removeExpense(index)}
                        data-testid={`button-remove-expense-${index}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name={`expenses.${index}.type`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-expense-type-${index}`}>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="HRA">HRA (House Rent Allowance)</SelectItem>
                                <SelectItem value="80C Investments">80C Investments</SelectItem>
                                <SelectItem value="80D Health Insurance">80D Health Insurance</SelectItem>
                                <SelectItem value="Education">Education</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`expenses.${index}.amount`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} placeholder="50000" data-testid={`input-expense-amount-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name={`expenses.${index}.isEligibleForDeduction`}
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid={`checkbox-expense-deduction-${index}`}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Eligible for tax deduction</FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => appendExpense({ type: "", amount: 0, isEligibleForDeduction: false, details: "" })}
                  className="w-full"
                  data-testid="button-add-expense"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Expense
                </Button>
              </CardContent>
            </Card>

            {hasBusinessIncome && (
              <Card data-testid="card-business-details">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building className="h-5 w-5" />
                    Business Details
                  </CardTitle>
                  <CardDescription>Provide information about your business</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="businessDetails.businessType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Type</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., Retail, Consulting" data-testid="input-business-type" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="businessDetails.revenue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Annual Revenue (₹)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} placeholder="1000000" data-testid="input-business-revenue" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="businessDetails.profitMargin"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Profit Margin (%)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} placeholder="20" data-testid="input-business-profit-margin" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="businessDetails.hasAssets"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-business-has-assets"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Business owns depreciable assets</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            )}

            <Card data-testid="card-assets">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Assets
                </CardTitle>
                <CardDescription>List your major assets and investments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {assetFields.map((field, index) => (
                  <div key={field.id} className="border p-4 rounded-lg space-y-4" data-testid={`asset-${index}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Asset {index + 1}</h4>
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        onClick={() => removeAsset(index)}
                        data-testid={`button-remove-asset-${index}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <FormField
                      control={form.control}
                      name={`assets.${index}.type`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid={`select-asset-type-${index}`}>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Depreciable">Depreciable (Machinery, Computers, etc.)</SelectItem>
                              <SelectItem value="Non-Depreciable">Non-Depreciable (Land, etc.)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name={`assets.${index}.purchaseValue`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Purchase Value (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} placeholder="100000" data-testid={`input-asset-purchase-value-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`assets.${index}.currentValue`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Value (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} placeholder="80000" data-testid={`input-asset-current-value-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name={`assets.${index}.purchaseDate`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Purchase Date</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} data-testid={`input-asset-purchase-date-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      {form.watch(`assets.${index}.type`) === "Depreciable" && (
                        <FormField
                          control={form.control}
                          name={`assets.${index}.depreciationRate`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Depreciation Rate (%)</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} placeholder="15" data-testid={`input-asset-depreciation-rate-${index}`} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => appendAsset({ type: "", purchaseValue: 0, currentValue: 0, depreciationRate: 0, purchaseDate: "" })}
                  className="w-full"
                  data-testid="button-add-asset"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Asset
                </Button>
              </CardContent>
            </Card>

            <Button
              type="submit"
              className="w-full"
              disabled={createProfileMutation.isPending}
              data-testid="button-submit-profile"
            >
              {createProfileMutation.isPending ? "Analyzing..." : "Analyze Tax Strategies"}
            </Button>
          </form>
        </Form>

        {strategiesData && strategiesData.length > 0 && (
          <div className="mt-8 space-y-6">
            <Separator />
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <TrendingUp className="h-6 w-6" />
                Detected Tax Strategies
              </h2>
              <div className="grid gap-4">
                {strategiesData.map((strategy: any, index: number) => (
                  <Card key={strategy.id} data-testid={`strategy-card-${index}`}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span data-testid={`strategy-type-${index}`}>{strategy.strategyType}</span>
                        <span className="text-2xl font-bold text-green-600" data-testid={`strategy-savings-${index}`}>
                          ₹{parseFloat(strategy.potentialSaving).toLocaleString()}
                        </span>
                      </CardTitle>
                      <CardDescription>
                        Confidence: {(parseFloat(strategy.confidence) * 100).toFixed(0)}%
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-700" data-testid={`strategy-description-${index}`}>{strategy.description}</p>
                      
                      {strategy.statutoryRefs && strategy.statutoryRefs.length > 0 && (
                        <div>
                          <h4 className="font-semibold mb-2 flex items-center gap-2">
                            <FileText className="h-4 w-4" />
                            Statutory References
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {strategy.statutoryRefs.map((ref: string, refIndex: number) => (
                              <span
                                key={refIndex}
                                className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm"
                                data-testid={`strategy-ref-${index}-${refIndex}`}
                              >
                                {ref}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {strategy.requiredActions && strategy.requiredActions.length > 0 && (
                        <div>
                          <h4 className="font-semibold mb-2 flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Required Actions
                          </h4>
                          <ul className="list-disc list-inside space-y-1">
                            {strategy.requiredActions.map((action: string, actionIndex: number) => (
                              <li key={actionIndex} className="text-gray-700" data-testid={`strategy-action-${index}-${actionIndex}`}>
                                {action}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}

        {questionsData && questionsData.length > 0 && (
          <div className="mt-8 space-y-6">
            <Separator />
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Lightbulb className="h-6 w-6" />
                Proactive Questions
              </h2>
              <div className="grid gap-4">
                {questionsData.map((question: any, index: number) => (
                  <Card key={question.id} data-testid={`question-card-${index}`}>
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="h-5 w-5 text-amber-500 mt-1" />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900 mb-2" data-testid={`question-text-${index}`}>
                            {question.question}
                          </p>
                          {question.context && (
                            <p className="text-sm text-gray-500" data-testid={`question-context-${index}`}>
                              {question.context}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
