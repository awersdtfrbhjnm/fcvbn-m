import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Link } from 'wouter';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import ChatMessage from '@/components/ChatMessage';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import type { ChatMessage as ChatMessageType, ChatRequest, ChatResponse, TaxStrategy, FollowupQuestion } from '@shared/schema';
import { Sparkles, X, TrendingUp, HelpCircle, FileText } from 'lucide-react';

const SESSION_ID_KEY = 'taxbot-session-id';

function generateSessionId(): string {
  return `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export default function ChatPage() {
  const [input, setInput] = useState('');
  const [sessionId, setSessionId] = useState<string>('');
  const [userId, setUserId] = useState<string>('');
  const [profileId, setProfileId] = useState<string>('');
  const [lastResponse, setLastResponse] = useState<ChatResponse | null>(null);
  const [showBanner, setShowBanner] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Initialize session and load profile
  useEffect(() => {
    let storedSessionId = localStorage.getItem(SESSION_ID_KEY);
    if (!storedSessionId) {
      storedSessionId = generateSessionId();
      localStorage.setItem(SESSION_ID_KEY, storedSessionId);
    }
    setSessionId(storedSessionId);

    // Load financial profile info from localStorage
    const storedProfileId = localStorage.getItem('tax-profile-id');
    const storedUserId = localStorage.getItem('tax-user-id');
    
    if (storedProfileId) setProfileId(storedProfileId);
    if (storedUserId) setUserId(storedUserId);
  }, []);

  // Fetch chat history
  const { data: messages = [], isLoading } = useQuery<ChatMessageType[]>({
    queryKey: ['/api/chat', sessionId],
    enabled: !!sessionId,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (request: ChatRequest): Promise<ChatResponse> => {
      const response = await apiRequest('POST', '/api/chat', request);
      return response.json();
    },
    onSuccess: (data) => {
      setLastResponse(data);
      queryClient.invalidateQueries({ queryKey: ['/api/chat', sessionId] });
    },
    onError: (error) => {
      console.error('Send message error:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Auto-scroll to bottom
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, sendMessageMutation.isPending]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [input]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !sessionId || sendMessageMutation.isPending) return;

    const message = input.trim();
    setInput('');

    sendMessageMutation.mutate({
      message,
      sessionId,
      userId: userId || undefined
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleTopicClick = (topic: string) => {
    setInput(`Tell me about ${topic}`);
    textareaRef.current?.focus();
  };

  const handleSectionClick = (section: any) => {
    setInput(`Explain Section ${section.sectionNumber} in detail`);
    textareaRef.current?.focus();
  };

  const handleQuickAction = (action: string) => {
    const quickQueries = {
      'search': 'Search for a specific section number',
      'calculation': 'How do I calculate my tax liability?',
      'deductions': 'What are all the available tax deductions?',
      'recent': 'What are the recent changes in Income Tax Act?'
    };
    
    const query = quickQueries[action as keyof typeof quickQueries];
    if (query) {
      setInput(query);
      textareaRef.current?.focus();
    }
  };

  const welcomeMessage: ChatMessageType = {
    id: 'welcome',
    sessionId: '',
    userId: null,
    content: "Hello! I'm your Income Tax Act assistant. I have the complete Income Tax Act loaded and can help you find specific sections, understand provisions, and answer your tax-related questions based on the official Act.",
    role: 'assistant',
    sources: [],
    createdAt: new Date()
  };

  return (
    <div className="min-h-screen bg-legal-gray">
      <Header />
      
      <div className="max-w-7xl mx-auto flex h-[calc(100vh-4rem)]">
        <Sidebar 
          onTopicClick={handleTopicClick}
          onSectionClick={handleSectionClick}
        />
        
        {/* Main Chat Area */}
        <main className="flex-1 flex flex-col bg-chat-bg">
          
          {/* Tax Planning Mode Banner */}
          {profileId && showBanner && (
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-blue-200 p-4" data-testid="banner-tax-planning-active">
              <div className="max-w-4xl mx-auto flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-500 rounded-full p-2">
                    <Sparkles className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-blue-900 flex items-center gap-2">
                      Tax Planning Mode Active
                      <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                        AI-Powered
                      </Badge>
                    </h3>
                    <p className="text-sm text-blue-700">
                      Personalized tax strategies based on your financial profile
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Link href="/tax-planning">
                    <Button variant="outline" size="sm" className="text-blue-700 border-blue-300 hover:bg-blue-100" data-testid="button-view-profile">
                      <FileText className="h-4 w-4 mr-1" />
                      View Profile
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowBanner(false)}
                    className="text-blue-700 hover:bg-blue-100"
                    data-testid="button-close-banner"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Chat Messages Container */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Welcome Message */}
            {messages.length === 0 && (
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-robot text-white text-sm"></i>
                </div>
                <div className="flex-1">
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                    <div className="text-sm text-gray-900 leading-relaxed">
                      {welcomeMessage.content}
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button 
                        onClick={() => handleTopicClick('80C deductions')}
                        className="px-3 py-1 bg-gray-100 text-gray-700 text-xs rounded-full hover:bg-gray-200 transition-colors"
                      >
                        <i className="fas fa-lightbulb mr-1"></i>What are 80C deductions?
                      </button>
                      <button 
                        onClick={() => handleTopicClick('TDS on salary')}
                        className="px-3 py-1 bg-gray-100 text-gray-700 text-xs rounded-full hover:bg-gray-200 transition-colors"
                      >
                        <i className="fas fa-lightbulb mr-1"></i>TDS on salary explained
                      </button>
                      <button 
                        onClick={() => handleTopicClick('Capital gains exemptions')}
                        className="px-3 py-1 bg-gray-100 text-gray-700 text-xs rounded-full hover:bg-gray-200 transition-colors"
                      >
                        <i className="fas fa-lightbulb mr-1"></i>Capital gains exemptions
                      </button>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">AI Assistant • Just now</div>
                </div>
              </div>
            )}
            
            {/* Chat Messages */}
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : (
              messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))
            )}
            
            {/* Loading indicator for pending message */}
            {sendMessageMutation.isPending && (
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-robot text-white text-sm"></i>
                </div>
                <div className="flex-1">
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-2 text-gray-500 text-sm">
                      <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full"></div>
                      <span>Searching Income Tax Act sections...</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tax Strategies Cards */}
            {lastResponse && lastResponse.strategies && lastResponse.strategies.length > 0 && (
              <div className="space-y-3" data-testid="strategies-container">
                <div className="flex items-center space-x-2 text-sm font-medium text-gray-700">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  <span>Tax Saving Strategies Detected</span>
                </div>
                {lastResponse.strategies.map((strategy, index) => (
                  <Card key={strategy.id} className="p-4 border-l-4 border-l-green-500" data-testid={`strategy-card-${index}`}>
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                            {strategy.strategyType}
                            <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                              {(parseFloat(strategy.confidence) * 100).toFixed(0)}% confidence
                            </Badge>
                          </h4>
                          <p className="text-sm text-gray-600 mt-1">{strategy.description}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm">
                        <div className="flex items-center space-x-1 text-green-600 font-semibold">
                          <span>Potential Saving:</span>
                          <span>₹{parseFloat(strategy.potentialSaving).toLocaleString('en-IN')}</span>
                        </div>
                        {strategy.statutoryRefs && strategy.statutoryRefs.length > 0 && (
                          <div className="flex items-center space-x-1 text-gray-500">
                            <i className="fas fa-balance-scale text-xs"></i>
                            <span className="text-xs">{strategy.statutoryRefs.join(', ')}</span>
                          </div>
                        )}
                      </div>
                      
                      {strategy.requiredActions && strategy.requiredActions.length > 0 && (
                        <div className="bg-gray-50 rounded p-3">
                          <p className="text-xs font-medium text-gray-700 mb-2">Required Actions:</p>
                          <ul className="text-xs text-gray-600 space-y-1">
                            {strategy.requiredActions.map((action, idx) => (
                              <li key={idx} className="flex items-start space-x-2">
                                <span className="text-primary">•</span>
                                <span>{action}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
                <Link href="/tax-planning">
                  <Button variant="outline" className="w-full" data-testid="button-view-full-plan">
                    <FileText className="h-4 w-4 mr-2" />
                    View Full Tax Plan
                  </Button>
                </Link>
              </div>
            )}

            {/* Followup Questions */}
            {lastResponse && lastResponse.followupQuestions && lastResponse.followupQuestions.length > 0 && (
              <div className="space-y-3" data-testid="followup-questions-container">
                <div className="flex items-center space-x-2 text-sm font-medium text-gray-700">
                  <HelpCircle className="h-5 w-5 text-blue-600" />
                  <span>Suggested Questions to Optimize Your Tax</span>
                </div>
                {lastResponse.followupQuestions.slice(0, 3).map((question, index) => (
                  <Card 
                    key={question.id} 
                    className="p-4 border-l-4 border-l-blue-500 cursor-pointer hover:bg-blue-50 transition-colors"
                    onClick={() => setInput(question.question)}
                    data-testid={`followup-question-${index}`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-xs font-medium text-blue-600">{question.priority || index + 1}</span>
                        </div>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-900">{question.question}</p>
                        {question.context && (
                          <p className="text-xs text-gray-500 mt-1">{question.context}</p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
          
          {/* Chat Input Area */}
          <div className="border-t border-gray-200 bg-white p-4">
            <div className="max-w-4xl mx-auto">
              <form onSubmit={handleSubmit} className="flex items-end space-x-3">
                <div className="flex-1">
                  <div className="relative">
                    <textarea 
                      ref={textareaRef}
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Ask me anything about the Income Tax Act..." 
                      className="w-full p-4 pr-12 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent resize-none text-sm"
                      rows={2}
                      maxLength={2000}
                      disabled={sendMessageMutation.isPending}
                    />
                    <button 
                      type="button"
                      className="absolute right-3 bottom-3 p-2 text-gray-400 hover:text-primary transition-colors"
                    >
                      <i className="fas fa-paperclip"></i>
                    </button>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>Press Enter to send, Shift + Enter for new line</span>
                    </div>
                    <div className="text-xs text-gray-500">
                      <span>{input.length}</span>/2000
                    </div>
                  </div>
                </div>
                <button 
                  type="submit"
                  disabled={!input.trim() || sendMessageMutation.isPending}
                  className="bg-primary hover:bg-blue-700 text-white p-3 rounded-xl transition-colors flex items-center justify-center min-w-[48px] h-12 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-paper-plane text-lg"></i>
                </button>
              </form>
              
              {/* Quick Actions */}
              <div className="mt-3 flex flex-wrap gap-2">
                <button 
                  onClick={() => handleQuickAction('search')}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-full transition-colors"
                >
                  <i className="fas fa-search mr-1"></i>Search specific section
                </button>
                <button 
                  onClick={() => handleQuickAction('calculation')}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-full transition-colors"
                >
                  <i className="fas fa-calculator mr-1"></i>Tax calculation help
                </button>
                <button 
                  onClick={() => handleQuickAction('deductions')}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-full transition-colors"
                >
                  <i className="fas fa-list mr-1"></i>Show all deductions
                </button>
                <button 
                  onClick={() => handleQuickAction('recent')}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-full transition-colors"
                >
                  <i className="fas fa-history mr-1"></i>Recent changes
                </button>
              </div>
            </div>
          </div>
          
        </main>
        
      </div>
      
      {/* Mobile Menu Toggle */}
      <button className="lg:hidden fixed bottom-4 left-4 w-12 h-12 bg-primary text-white rounded-full shadow-lg flex items-center justify-center z-50">
        <i className="fas fa-bars"></i>
      </button>
    </div>
  );
}
