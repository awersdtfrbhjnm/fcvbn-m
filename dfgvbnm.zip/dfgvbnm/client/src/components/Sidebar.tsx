import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';

interface RecentSection {
  id: string;
  title: string;
  sectionNumber: string;
  description: string;
}

interface AppData {
  recentSections: RecentSection[];
  popularTopics: string[];
  stats: {
    totalSections: number;
    pagesIndexed: number;
  };
}

interface SidebarProps {
  onTopicClick?: (topic: string) => void;
  onSectionClick?: (section: RecentSection) => void;
}



export default function Sidebar({ onTopicClick, onSectionClick }: SidebarProps) {
  const [searchValue, setSearchValue] = useState('');
  const [location] = useLocation();
  
  const { data: appData, isLoading } = useQuery<AppData>({
    queryKey: ['/api/app-data'],
  });

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchValue.trim() && onTopicClick) {
      onTopicClick(searchValue.trim());
      setSearchValue('');
    }
  };

  if (isLoading) {
    return (
      <aside className="w-80 bg-white border-r border-gray-200 flex flex-col hidden lg:flex">
        <div className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 rounded mb-4 w-3/4"></div>
            <div className="h-10 bg-gray-200 rounded mb-4"></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="h-16 bg-gray-200 rounded"></div>
              <div className="h-16 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-80 bg-white border-r border-gray-200 flex flex-col hidden lg:flex">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Income Tax Act</h2>
        
        {/* Navigation Menu */}
        <nav className="mb-4 space-y-1">
          <Link 
            href="/"
            className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              location === '/' 
                ? 'bg-primary text-white' 
                : 'text-gray-700 hover:bg-gray-100'
            }`}
            data-testid="link-chat"
          >
            💬 Chat Assistant
          </Link>
          <Link 
            href="/tax-planning"
            className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              location === '/tax-planning' 
                ? 'bg-primary text-white' 
                : 'text-gray-700 hover:bg-gray-100'
            }`}
            data-testid="link-tax-planning"
          >
            📊 Tax Planning
          </Link>
        </nav>
        
        {/* Search Document */}
        <form onSubmit={handleSearchSubmit} className="relative mb-4">
          <input 
            type="text" 
            placeholder="Search sections..." 
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-sm"
          />
          <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
        </form>
        


        {/* Quick Stats */}
        {appData && (
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-legal-gray p-3 rounded-lg">
              <div className="text-2xl font-bold text-primary">{appData.stats.totalSections}</div>
              <div className="text-xs text-gray-600">Total Sections</div>
            </div>
            <div className="bg-legal-gray p-3 rounded-lg">
              <div className="text-2xl font-bold text-accent">{appData.stats.pagesIndexed}</div>
              <div className="text-xs text-gray-600">Pages Indexed</div>
            </div>
          </div>
        )}
      </div>
      
      {/* Document Navigation */}
      <div className="flex-1 overflow-y-auto p-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Recent Sections</h3>
        
        {appData && (
          <div className="space-y-2 mb-6">
            {appData.recentSections.map((section) => (
              <button 
                key={section.id}
                onClick={() => onSectionClick?.(section)}
                className="w-full text-left p-3 hover:bg-gray-50 rounded-lg border border-gray-100 transition-colors"
              >
                <div className="font-medium text-sm text-gray-900">Section {section.sectionNumber}</div>
                <div className="text-xs text-gray-500 mt-1">{section.description}</div>
              </button>
            ))}
          </div>
        )}
        
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Popular Topics</h3>
        {appData && (
          <div className="flex flex-wrap gap-2">
            {appData.popularTopics.map((topic) => (
              <button
                key={topic}
                onClick={() => onTopicClick?.(topic)}
                className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full cursor-pointer hover:bg-primary/20 transition-colors"
              >
                {topic}
              </button>
            ))}
          </div>
        )}
      </div>


    </aside>
  );
}
