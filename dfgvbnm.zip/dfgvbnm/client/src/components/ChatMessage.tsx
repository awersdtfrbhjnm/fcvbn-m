import React from 'react';
import type { ChatMessage as ChatMessageType, MessageSource } from '@shared/schema';

interface ChatMessageProps {
  message: ChatMessageType;
  isLoading?: boolean;
}

function SourceReferences({ sources }: { sources: MessageSource[] }) {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="mt-4 pt-3 border-t border-gray-100">
      <div className="text-xs font-medium text-gray-700 mb-2">Sources from Income Tax Act:</div>
      <div className="space-y-2">
        {sources.map((source, index) => (
          <div key={`${source.sectionId}-${index}`} className="flex items-center space-x-2 text-xs text-gray-600 bg-gray-50 p-2 rounded">
            <i className="fas fa-file-text text-primary"></i>
            <span className="font-medium">Section {source.sectionNumber}</span>
            <span>•</span>
            <span>Page {source.pageNumbers.join(', ')}</span>
            <button className="ml-auto text-primary hover:text-blue-800 font-medium">View</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function LoadingIndicator() {
  return (
    <div className="flex items-center space-x-2 text-gray-500 text-sm">
      <div className="flex space-x-1">
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
      </div>
      <span>Analyzing relevant sections...</span>
    </div>
  );
}

function formatMessageContent(content: string): React.ReactNode {
  // Simple formatter for basic markdown-like syntax
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    if (line.trim().startsWith('**') && line.trim().endsWith('**')) {
      // Bold text
      elements.push(
        <p key={i} className="font-semibold text-accent mb-2">
          {line.replace(/\*\*/g, '')}
        </p>
      );
    } else if (line.trim().startsWith('- ') || line.trim().startsWith('• ')) {
      // List items
      elements.push(
        <li key={i} className="ml-4">
          {line.replace(/^[-•]\s*/, '')}
        </li>
      );
    } else if (line.trim()) {
      // Regular paragraphs
      elements.push(
        <p key={i} className="mb-3 last:mb-0">
          {line}
        </p>
      );
    }
  }
  
  return elements;
}

export default function ChatMessage({ message, isLoading = false }: ChatMessageProps) {
  const isUser = message.role === 'user';
  const timeAgo = message.createdAt 
    ? new Date(message.createdAt).toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit', 
        hour12: true 
      })
    : 'Just now';

  if (isUser) {
    return (
      <div className="flex items-start space-x-3 justify-end">
        <div className="flex-1">
          <div className="bg-primary p-4 rounded-lg text-white ml-12">
            <div className="text-sm leading-relaxed">
              {message.content}
            </div>
          </div>
          <div className="text-xs text-gray-500 mt-2 text-right">You • {timeAgo}</div>
        </div>
        <div className="flex-shrink-0 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
          <i className="fas fa-user text-gray-600 text-sm"></i>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-3">
      <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
        <i className="fas fa-robot text-white text-sm"></i>
      </div>
      <div className="flex-1">
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
          {isLoading ? (
            <LoadingIndicator />
          ) : (
            <>
              <div className="text-sm text-gray-900 leading-relaxed">
                {formatMessageContent(message.content)}
              </div>
              
              <SourceReferences sources={message.sources || []} />
            </>
          )}
        </div>
        <div className="text-xs text-gray-500 mt-2">AI Assistant • {timeAgo}</div>
      </div>
    </div>
  );
}
