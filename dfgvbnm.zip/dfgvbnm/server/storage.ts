import { 
  type User, 
  type InsertUser, 
  type Document, 
  type InsertDocument,
  type ChatMessage,
  type InsertChatMessage,
  type SearchResult,
  type DocumentSection,
  type FinancialProfile,
  type InsertFinancialProfile,
  type IncomeSource,
  type InsertIncomeSource,
  type Expense,
  type InsertExpense,
  type Asset,
  type InsertAsset,
  type BusinessDetails,
  type InsertBusinessDetails,
  type TaxStrategy,
  type InsertTaxStrategy,
  type FollowupQuestion,
  type InsertFollowupQuestion
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Documents
  getDocument(id: string): Promise<Document | undefined>;
  getAllDocuments(): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  deleteDocument(id: string): Promise<boolean>;
  searchDocumentSections(keywords: string[]): Promise<SearchResult[]>;

  // Chat Messages
  getChatMessage(id: string): Promise<ChatMessage | undefined>;
  getChatMessagesBySession(sessionId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Search
  searchContent(query: string): Promise<SearchResult[]>;

  // Financial Profiles
  getFinancialProfile(id: string): Promise<FinancialProfile | undefined>;
  getFinancialProfileByUserId(userId: string): Promise<FinancialProfile | undefined>;
  createFinancialProfile(profile: InsertFinancialProfile): Promise<FinancialProfile>;
  updateFinancialProfile(id: string, profile: Partial<InsertFinancialProfile>): Promise<FinancialProfile | undefined>;
  deleteFinancialProfile(id: string): Promise<boolean>;

  // Income Sources
  getIncomeSource(id: string): Promise<IncomeSource | undefined>;
  getIncomeSourcesByProfileId(profileId: string): Promise<IncomeSource[]>;
  createIncomeSource(source: InsertIncomeSource): Promise<IncomeSource>;
  updateIncomeSource(id: string, source: Partial<InsertIncomeSource>): Promise<IncomeSource | undefined>;
  deleteIncomeSource(id: string): Promise<boolean>;

  // Expenses
  getExpense(id: string): Promise<Expense | undefined>;
  getExpensesByProfileId(profileId: string): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: string): Promise<boolean>;

  // Assets
  getAsset(id: string): Promise<Asset | undefined>;
  getAssetsByProfileId(profileId: string): Promise<Asset[]>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: string, asset: Partial<InsertAsset>): Promise<Asset | undefined>;
  deleteAsset(id: string): Promise<boolean>;

  // Business Details
  getBusinessDetails(id: string): Promise<BusinessDetails | undefined>;
  getBusinessDetailsByProfileId(profileId: string): Promise<BusinessDetails | undefined>;
  createBusinessDetails(details: InsertBusinessDetails): Promise<BusinessDetails>;
  updateBusinessDetails(id: string, details: Partial<InsertBusinessDetails>): Promise<BusinessDetails | undefined>;
  deleteBusinessDetails(id: string): Promise<boolean>;

  // Tax Strategies
  getTaxStrategy(id: string): Promise<TaxStrategy | undefined>;
  getTaxStrategiesByProfileId(profileId: string): Promise<TaxStrategy[]>;
  createTaxStrategy(strategy: InsertTaxStrategy): Promise<TaxStrategy>;
  updateTaxStrategy(id: string, strategy: Partial<InsertTaxStrategy>): Promise<TaxStrategy | undefined>;
  deleteTaxStrategy(id: string): Promise<boolean>;

  // Followup Questions
  getFollowupQuestion(id: string): Promise<FollowupQuestion | undefined>;
  getFollowupQuestionsByProfileId(profileId: string): Promise<FollowupQuestion[]>;
  createFollowupQuestion(question: InsertFollowupQuestion): Promise<FollowupQuestion>;
  updateFollowupQuestion(id: string, question: Partial<InsertFollowupQuestion>): Promise<FollowupQuestion | undefined>;
  deleteFollowupQuestion(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private documents: Map<string, Document>;
  private chatMessages: Map<string, ChatMessage>;
  private financialProfiles: Map<string, FinancialProfile>;
  private incomeSources: Map<string, IncomeSource>;
  private expenses: Map<string, Expense>;
  private assets: Map<string, Asset>;
  private businessDetails: Map<string, BusinessDetails>;
  private taxStrategies: Map<string, TaxStrategy>;
  private followupQuestions: Map<string, FollowupQuestion>;

  constructor() {
    this.users = new Map();
    this.documents = new Map();
    this.chatMessages = new Map();
    this.financialProfiles = new Map();
    this.incomeSources = new Map();
    this.expenses = new Map();
    this.assets = new Map();
    this.businessDetails = new Map();
    this.taxStrategies = new Map();
    this.followupQuestions = new Map();
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Documents
  async getDocument(id: string): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const document: Document = { 
      ...insertDocument, 
      id, 
      createdAt: new Date(),
      sections: (Array.isArray(insertDocument.sections) ? insertDocument.sections : []) as any
    };
    this.documents.set(id, document);
    return document;
  }

  async deleteDocument(id: string): Promise<boolean> {
    return this.documents.delete(id);
  }

  async searchDocumentSections(keywords: string[]): Promise<SearchResult[]> {
    const results: SearchResult[] = [];
    const searchTerms = keywords.map(k => k.toLowerCase());

    for (const document of Array.from(this.documents.values())) {
      if (document.sections && Array.isArray(document.sections)) {
        for (const section of document.sections) {
          const searchableContent = `${section.title} ${section.content} ${section.sectionNumber}`.toLowerCase();
          
          let relevanceScore = 0;
          let matchCount = 0;
          
          for (const term of searchTerms) {
            const matches = (searchableContent.match(new RegExp(term, 'g')) || []).length;
            if (matches > 0) {
              matchCount++;
              relevanceScore += matches;
            }
          }
          
          if (matchCount > 0) {
            results.push({
              sectionId: section.id,
              sectionTitle: section.title,
              sectionNumber: section.sectionNumber,
              content: section.content,
              pageNumbers: section.pageNumbers,
              relevanceScore: relevanceScore / searchTerms.length
            });
          }
        }
      }
    }

    return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
  }

  // Chat Messages
  async getChatMessage(id: string): Promise<ChatMessage | undefined> {
    return this.chatMessages.get(id);
  }

  async getChatMessagesBySession(sessionId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.sessionId === sessionId)
      .sort((a, b) => (a.createdAt?.getTime() || 0) - (b.createdAt?.getTime() || 0));
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { 
      ...insertMessage,
      userId: insertMessage.userId || null,
      id,
      createdAt: new Date(),
      sources: (Array.isArray(insertMessage.sources) ? insertMessage.sources : []) as any
    };
    this.chatMessages.set(id, message);
    return message;
  }

  // Search
  async searchContent(query: string): Promise<SearchResult[]> {
    const keywords = query.toLowerCase().split(' ').filter(word => word.length > 2);
    return this.searchDocumentSections(keywords);
  }

  // Financial Profiles
  async getFinancialProfile(id: string): Promise<FinancialProfile | undefined> {
    return this.financialProfiles.get(id);
  }

  async getFinancialProfileByUserId(userId: string): Promise<FinancialProfile | undefined> {
    return Array.from(this.financialProfiles.values()).find(
      (profile) => profile.userId === userId,
    );
  }

  async createFinancialProfile(insertProfile: InsertFinancialProfile): Promise<FinancialProfile> {
    const id = randomUUID();
    const profile: FinancialProfile = {
      id,
      userId: insertProfile.userId,
      taxpayerInfo: insertProfile.taxpayerInfo as any,
      spouseInfo: (insertProfile.spouseInfo ?? null) as any,
      dependents: (insertProfile.dependents ?? null) as any,
      totalIncome: insertProfile.totalIncome,
      incomeBreakdown: insertProfile.incomeBreakdown as any,
      createdAt: new Date(),
    };
    this.financialProfiles.set(id, profile);
    return profile;
  }

  async updateFinancialProfile(id: string, updates: Partial<InsertFinancialProfile>): Promise<FinancialProfile | undefined> {
    const profile = this.financialProfiles.get(id);
    if (!profile) return undefined;
    
    const updated = { ...profile, ...updates } as FinancialProfile;
    this.financialProfiles.set(id, updated);
    return updated;
  }

  async deleteFinancialProfile(id: string): Promise<boolean> {
    return this.financialProfiles.delete(id);
  }

  // Income Sources
  async getIncomeSource(id: string): Promise<IncomeSource | undefined> {
    return this.incomeSources.get(id);
  }

  async getIncomeSourcesByProfileId(profileId: string): Promise<IncomeSource[]> {
    return Array.from(this.incomeSources.values()).filter(
      (source) => source.profileId === profileId,
    );
  }

  async createIncomeSource(insertSource: InsertIncomeSource): Promise<IncomeSource> {
    const id = randomUUID();
    const source: IncomeSource = {
      ...insertSource,
      id,
      createdAt: new Date(),
      details: insertSource.details ?? null,
    };
    this.incomeSources.set(id, source);
    return source;
  }

  async updateIncomeSource(id: string, updates: Partial<InsertIncomeSource>): Promise<IncomeSource | undefined> {
    const source = this.incomeSources.get(id);
    if (!source) return undefined;
    
    const updated = { ...source, ...updates };
    this.incomeSources.set(id, updated);
    return updated;
  }

  async deleteIncomeSource(id: string): Promise<boolean> {
    return this.incomeSources.delete(id);
  }

  // Expenses
  async getExpense(id: string): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }

  async getExpensesByProfileId(profileId: string): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(
      (expense) => expense.profileId === profileId,
    );
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const id = randomUUID();
    const expense: Expense = {
      ...insertExpense,
      id,
      createdAt: new Date(),
      details: insertExpense.details ?? null,
      isEligibleForDeduction: insertExpense.isEligibleForDeduction ?? null,
    };
    this.expenses.set(id, expense);
    return expense;
  }

  async updateExpense(id: string, updates: Partial<InsertExpense>): Promise<Expense | undefined> {
    const expense = this.expenses.get(id);
    if (!expense) return undefined;
    
    const updated = { ...expense, ...updates };
    this.expenses.set(id, updated);
    return updated;
  }

  async deleteExpense(id: string): Promise<boolean> {
    return this.expenses.delete(id);
  }

  // Assets
  async getAsset(id: string): Promise<Asset | undefined> {
    return this.assets.get(id);
  }

  async getAssetsByProfileId(profileId: string): Promise<Asset[]> {
    return Array.from(this.assets.values()).filter(
      (asset) => asset.profileId === profileId,
    );
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const id = randomUUID();
    const asset: Asset = {
      ...insertAsset,
      id,
      createdAt: new Date(),
      depreciationRate: insertAsset.depreciationRate ?? null,
    };
    this.assets.set(id, asset);
    return asset;
  }

  async updateAsset(id: string, updates: Partial<InsertAsset>): Promise<Asset | undefined> {
    const asset = this.assets.get(id);
    if (!asset) return undefined;
    
    const updated = { ...asset, ...updates };
    this.assets.set(id, updated);
    return updated;
  }

  async deleteAsset(id: string): Promise<boolean> {
    return this.assets.delete(id);
  }

  // Business Details
  async getBusinessDetails(id: string): Promise<BusinessDetails | undefined> {
    return this.businessDetails.get(id);
  }

  async getBusinessDetailsByProfileId(profileId: string): Promise<BusinessDetails | undefined> {
    return Array.from(this.businessDetails.values()).find(
      (details) => details.profileId === profileId,
    );
  }

  async createBusinessDetails(insertDetails: InsertBusinessDetails): Promise<BusinessDetails> {
    const id = randomUUID();
    const details: BusinessDetails = {
      ...insertDetails,
      id,
      createdAt: new Date(),
      hasAssets: insertDetails.hasAssets ?? null,
      profitMargin: insertDetails.profitMargin ?? null,
    };
    this.businessDetails.set(id, details);
    return details;
  }

  async updateBusinessDetails(id: string, updates: Partial<InsertBusinessDetails>): Promise<BusinessDetails | undefined> {
    const details = this.businessDetails.get(id);
    if (!details) return undefined;
    
    const updated = { ...details, ...updates };
    this.businessDetails.set(id, updated);
    return updated;
  }

  async deleteBusinessDetails(id: string): Promise<boolean> {
    return this.businessDetails.delete(id);
  }

  // Tax Strategies
  async getTaxStrategy(id: string): Promise<TaxStrategy | undefined> {
    return this.taxStrategies.get(id);
  }

  async getTaxStrategiesByProfileId(profileId: string): Promise<TaxStrategy[]> {
    return Array.from(this.taxStrategies.values()).filter(
      (strategy) => strategy.profileId === profileId,
    );
  }

  async createTaxStrategy(insertStrategy: InsertTaxStrategy): Promise<TaxStrategy> {
    const id = randomUUID();
    const strategy: TaxStrategy = {
      ...insertStrategy,
      id,
      detectedAt: new Date(),
      status: insertStrategy.status ?? "pending",
      statutoryRefs: insertStrategy.statutoryRefs ?? null,
      requiredActions: insertStrategy.requiredActions ?? null,
    };
    this.taxStrategies.set(id, strategy);
    return strategy;
  }

  async updateTaxStrategy(id: string, updates: Partial<InsertTaxStrategy>): Promise<TaxStrategy | undefined> {
    const strategy = this.taxStrategies.get(id);
    if (!strategy) return undefined;
    
    const updated = { ...strategy, ...updates };
    this.taxStrategies.set(id, updated);
    return updated;
  }

  async deleteTaxStrategy(id: string): Promise<boolean> {
    return this.taxStrategies.delete(id);
  }

  // Followup Questions
  async getFollowupQuestion(id: string): Promise<FollowupQuestion | undefined> {
    return this.followupQuestions.get(id);
  }

  async getFollowupQuestionsByProfileId(profileId: string): Promise<FollowupQuestion[]> {
    return Array.from(this.followupQuestions.values()).filter(
      (question) => question.profileId === profileId,
    );
  }

  async createFollowupQuestion(insertQuestion: InsertFollowupQuestion): Promise<FollowupQuestion> {
    const id = randomUUID();
    const question: FollowupQuestion = {
      ...insertQuestion,
      id,
      askedAt: new Date(),
      answeredAt: null,
      context: insertQuestion.context ?? null,
      priority: insertQuestion.priority ?? null,
    };
    this.followupQuestions.set(id, question);
    return question;
  }

  async updateFollowupQuestion(id: string, updates: Partial<InsertFollowupQuestion>): Promise<FollowupQuestion | undefined> {
    const question = this.followupQuestions.get(id);
    if (!question) return undefined;
    
    const updated = { ...question, ...updates };
    this.followupQuestions.set(id, updated);
    return updated;
  }

  async deleteFollowupQuestion(id: string): Promise<boolean> {
    return this.followupQuestions.delete(id);
  }
}

export const storage = new MemStorage();
