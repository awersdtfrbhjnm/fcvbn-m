import type { DocumentSection } from "@shared/schema";

export interface ProcessedDocument {
  title: string;
  content: string;
  sections: DocumentSection[];
}

export function processTaxActText(rawText: string): ProcessedDocument {
  // This is a simplified processor that would normally handle PDF parsing
  // For now, it processes pre-structured text content
  
  const sections: DocumentSection[] = [];
  const lines = rawText.split('\n');
  let currentSection: Partial<DocumentSection> | null = null;
  let contentBuffer: string[] = [];
  let sectionCounter = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Detect section headers (simple pattern matching)
    const sectionMatch = line.match(/^(Section\s+(\d+[A-Z]?))[\.:]\s*(.+)/i);
    if (sectionMatch) {
      // Save previous section if exists
      if (currentSection && currentSection.id) {
        currentSection.content = contentBuffer.join('\n').trim();
        sections.push(currentSection as DocumentSection);
      }
      
      // Start new section
      sectionCounter++;
      currentSection = {
        id: `section-${sectionCounter}`,
        title: sectionMatch[3] || `Section ${sectionMatch[2]}`,
        sectionNumber: sectionMatch[2],
        pageNumbers: [Math.floor(i / 50) + 1], // Rough page estimation
        content: ''
      };
      contentBuffer = [];
    } else if (currentSection) {
      // Add content to current section
      if (line.length > 0) {
        contentBuffer.push(line);
      }
    }
  }
  
  // Save last section
  if (currentSection && currentSection.id) {
    currentSection.content = contentBuffer.join('\n').trim();
    sections.push(currentSection as DocumentSection);
  }

  return {
    title: "Income Tax Act, 1961",
    content: rawText,
    sections
  };
}

export function extractKeywordsFromSection(section: DocumentSection): string[] {
  const text = `${section.title} ${section.content}`.toLowerCase();
  const words = text.match(/\b\w{3,}\b/g) || [];
  
  // Filter out common words and get unique keywords
  const stopWords = new Set(['the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'her', 'was', 'one', 'our', 'had', 'day', 'get', 'has', 'him', 'his', 'how', 'its', 'may', 'new', 'now', 'old', 'see', 'two', 'who', 'boy', 'did', 'man', 'men', 'put', 'say', 'she', 'too', 'use']);
  
  const keywords = Array.from(new Set(words))
    .filter(word => !stopWords.has(word) && word.length > 3)
    .slice(0, 20);
  
  return keywords;
}

export function calculateRelevanceScore(searchTerms: string[], content: string): number {
  const normalizedContent = content.toLowerCase();
  let score = 0;
  let totalTerms = searchTerms.length;
  
  for (const term of searchTerms) {
    const regex = new RegExp(term.toLowerCase(), 'gi');
    const matches = normalizedContent.match(regex);
    if (matches) {
      // Weight by frequency and position (earlier mentions get higher scores)
      score += matches.length * (1 + (0.1 * (normalizedContent.length - normalizedContent.indexOf(term)) / normalizedContent.length));
    }
  }
  
  return totalTerms > 0 ? score / totalTerms : 0;
}
