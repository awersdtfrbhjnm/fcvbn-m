import * as fs from 'fs';
import type { DocumentSection } from '@shared/schema';

export interface ProcessedPDFDocument {
  title: string;
  content: string;
  sections: DocumentSection[];
  totalPages: number;
}

export async function processPDFFile(filePath: string): Promise<ProcessedPDFDocument> {
  try {
    // Dynamically import pdf-parse to avoid initialization issues
    const pdfParse = await import('pdf-parse');
    const pdfBuffer = fs.readFileSync(filePath);
    const pdfData = await pdfParse.default(pdfBuffer);
    
    return processPDFText(pdfData.text, pdfData.numpages);
  } catch (error) {
    console.error('PDF processing error:', error);
    throw new Error(`Failed to process PDF: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function processPDFText(rawText: string, totalPages: number): ProcessedPDFDocument {
  const sections: DocumentSection[] = [];
  const lines = rawText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  
  let currentSection: Partial<DocumentSection> | null = null;
  let contentBuffer: string[] = [];
  let sectionCounter = 0;
  let currentPage = 1;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Detect page breaks (common patterns in PDFs)
    if (line.match(/^Page\s+\d+/i) || line.match(/^\d+$/)) {
      currentPage++;
      continue;
    }
    
    // Detect section headers with various patterns
    const sectionPatterns = [
      /^(Section\s+(\d+[A-Z]?))[\.:]\s*(.+)/i,
      /^(\d+[A-Z]?)[\.:]\s*(.+)/i,
      /^SECTION\s+(\d+[A-Z]?)[\s\-–—]*(.+)/i,
      /^(\d+[A-Z]?)\s*[–—-]\s*(.+)/i
    ];
    
    let sectionMatch = null;
    for (const pattern of sectionPatterns) {
      sectionMatch = line.match(pattern);
      if (sectionMatch) break;
    }
    
    if (sectionMatch) {
      // Save previous section if exists
      if (currentSection && currentSection.id) {
        currentSection.content = contentBuffer.join('\n').trim();
        if (currentSection.content.length > 0) {
          sections.push(currentSection as DocumentSection);
        }
      }
      
      // Start new section
      sectionCounter++;
      const sectionNumber = sectionMatch[2] || sectionMatch[1];
      const sectionTitle = sectionMatch[3] || sectionMatch[2] || `Section ${sectionNumber}`;
      
      currentSection = {
        id: `section-${sectionCounter}`,
        title: sectionTitle.trim(),
        sectionNumber: sectionNumber,
        pageNumbers: [currentPage],
        content: ''
      };
      contentBuffer = [];
    } else if (currentSection) {
      // Add content to current section
      if (line.length > 0 && !line.match(/^(Page\s+\d+|^\d+$)/i)) {
        contentBuffer.push(line);
        
        // Update page numbers if we detect content spans multiple pages
        if (!currentSection.pageNumbers?.includes(currentPage)) {
          currentSection.pageNumbers = [...(currentSection.pageNumbers || []), currentPage];
        }
      }
    } else if (line.length > 50) {
      // If we haven't found any sections yet, but have substantial content, create a general section
      if (sections.length === 0) {
        sectionCounter++;
        currentSection = {
          id: `section-${sectionCounter}`,
          title: 'General Provisions',
          sectionNumber: '0',
          pageNumbers: [currentPage],
          content: ''
        };
        contentBuffer = [line];
      }
    }
  }
  
  // Save last section
  if (currentSection && currentSection.id) {
    currentSection.content = contentBuffer.join('\n').trim();
    if (currentSection.content.length > 0) {
      sections.push(currentSection as DocumentSection);
    }
  }

  return {
    title: "Income Tax Act, 1961",
    content: rawText,
    sections,
    totalPages
  };
}

export function validatePDFContent(sections: DocumentSection[]): boolean {
  // Basic validation to ensure we have meaningful content
  if (sections.length === 0) return false;
  
  const totalContentLength = sections.reduce((acc, section) => acc + section.content.length, 0);
  if (totalContentLength < 1000) return false; // Minimum content threshold
  
  // Check if we have some sections with reasonable content
  const substantialSections = sections.filter(section => section.content.length > 100);
  return substantialSections.length >= Math.min(3, sections.length / 2);
}