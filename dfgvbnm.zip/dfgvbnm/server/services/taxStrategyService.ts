import { GoogleGenAI } from "@google/genai";
import type { 
  FinancialProfile, 
  SearchResult, 
  TaxStrategy, 
  FollowupQuestion,
  InsertTaxStrategy,
  InsertFollowupQuestion,
  IncomeSource,
  Expense,
  Asset,
  BusinessDetails
} from "@shared/schema";
import type { IStorage } from "../storage";

function validateGeminiApiKey(): string {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim() === "") {
    const errorMsg = "GEMINI_API_KEY environment variable is not set. Tax strategy analysis features will be disabled.";
    console.error(errorMsg);
    throw new Error(errorMsg);
  }
  return apiKey;
}

let ai: GoogleGenAI;
try {
  const apiKey = validateGeminiApiKey();
  ai = new GoogleGenAI({ apiKey });
  console.log("Gemini AI initialized successfully");
} catch (error) {
  console.error("Failed to initialize Gemini AI:", error);
}

export interface StrategyAnalysis {
  strategies: {
    type: string;
    description: string;
    potentialSaving: number;
    confidence: number;
    statutoryRefs: string[];
    requiredActions: string[];
  }[];
  totalPotentialSaving: number;
  summary: string;
}

export async function detectTaxOpportunities(
  profileId: string,
  storage: IStorage
): Promise<TaxStrategy[]> {
  try {
    const profile = await storage.getFinancialProfile(profileId);
    if (!profile) {
      throw new Error(`Financial profile ${profileId} not found`);
    }

    const existingStrategies = await storage.getTaxStrategiesByProfileId(profileId);
    
    const STRATEGY_REFRESH_INTERVAL_MS = 5 * 60 * 1000;
    if (existingStrategies.length > 0) {
      const latestStrategy = existingStrategies.sort((a, b) => 
        (b.detectedAt?.getTime() || 0) - (a.detectedAt?.getTime() || 0)
      )[0];
      
      const timeSinceLastDetection = Date.now() - (latestStrategy.detectedAt?.getTime() || 0);
      
      if (timeSinceLastDetection < STRATEGY_REFRESH_INTERVAL_MS) {
        console.log(`Using cached strategies (detected ${Math.round(timeSinceLastDetection / 1000)}s ago)`);
        return existingStrategies;
      }
      
      console.log(`Strategies are stale (${Math.round(timeSinceLastDetection / 1000)}s old), deleting and re-detecting...`);
      for (const strategy of existingStrategies) {
        await storage.deleteTaxStrategy(strategy.id);
      }
    }

    const relevantSections = await getRelevantActSections(profile, storage);
    
    if (relevantSections.length === 0) {
      console.log("No relevant Income Tax Act sections found for analysis");
      return [];
    }

    const analysis = await analyzeStrategyWithGemini(profile, relevantSections);

    const detectedStrategies: TaxStrategy[] = [];
    for (const strategy of analysis.strategies) {
      const taxStrategy: InsertTaxStrategy = {
        profileId: profileId,
        strategyType: strategy.type,
        description: strategy.description,
        potentialSaving: strategy.potentialSaving.toString(),
        confidence: strategy.confidence.toString(),
        statutoryRefs: strategy.statutoryRefs,
        requiredActions: strategy.requiredActions,
        status: "pending"
      };
      
      const created = await storage.createTaxStrategy(taxStrategy);
      detectedStrategies.push(created);
    }

    console.log(`Created ${detectedStrategies.length} new strategies for profile ${profileId}`);
    return detectedStrategies;

  } catch (error) {
    console.error("Error detecting tax opportunities:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error details:", errorMessage);
    
    const existingStrategies = await storage.getTaxStrategiesByProfileId(profileId);
    if (existingStrategies.length > 0) {
      console.log(`Returning ${existingStrategies.length} existing strategies due to error`);
      return existingStrategies;
    }
    
    return [];
  }
}

export async function generateProactiveQuestions(
  profileId: string,
  storage: IStorage
): Promise<FollowupQuestion[]> {
  try {
    const profile = await storage.getFinancialProfile(profileId);
    if (!profile) {
      throw new Error(`Financial profile ${profileId} not found`);
    }

    const existingQuestions = await storage.getFollowupQuestionsByProfileId(profileId);
    
    const unansweredQuestions = existingQuestions.filter(q => !q.answeredAt);
    if (unansweredQuestions.length > 0) {
      console.log(`Found ${unansweredQuestions.length} unanswered questions, skipping generation`);
      return existingQuestions.sort((a, b) => (b.priority || 0) - (a.priority || 0));
    }

    const incomeSources = await storage.getIncomeSourcesByProfileId(profileId);
    const expenses = await storage.getExpensesByProfileId(profileId);
    const assets = await storage.getAssetsByProfileId(profileId);
    const businessDetails = await storage.getBusinessDetailsByProfileId(profileId);

    const questions: InsertFollowupQuestion[] = [];
    let priority = 10;
    
    const existingContexts = new Set(existingQuestions.map(q => q.context?.toLowerCase() || ""));
    
    const shouldAddQuestion = (context: string): boolean => {
      return !existingContexts.has(context.toLowerCase());
    };

    const totalIncome = parseFloat(profile.totalIncome);

    if (profile.spouseInfo && !profile.spouseInfo.hasIncome && businessDetails) {
      const context = "Spouse with no income - employment opportunity";
      if (shouldAddQuestion(context)) {
        questions.push({
          profileId: profileId,
          question: "Your spouse currently has no income. If they can contribute to your business activities (accounting, administration, customer service, etc.), consider employing them at a reasonable salary. This creates a legitimate business expense for you while utilizing their ₹2.5 lakh basic exemption. Note: Direct transfer of income-generating assets to spouse would be clubbed under Section 64(1)(iv).",
          context: context,
          priority: priority--
        });
      }
    }

    if (profile.spouseInfo && profile.spouseInfo.hasIncome && profile.spouseInfo.income) {
      const spouseIncome = profile.spouseInfo.income;
      
      if (totalIncome > spouseIncome * 2) {
        const context = "Significant income disparity - strategic planning";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "There's a significant income difference between you and your spouse. While direct transfer of income-generating assets to spouse would trigger clubbing under Section 64(1)(iv), consider these compliant strategies: (1) If you have adult children, gift assets to them - no clubbing applies; (2) Form an HUF to create another taxable entity; (3) Ensure your spouse is employed at reasonable market salary if they work in your business.",
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (businessDetails && businessDetails.revenue) {
      const revenue = parseFloat(businessDetails.revenue);
      if (revenue > 1000000 && (!businessDetails.hasAssets || assets.length === 0)) {
        const context = "High revenue business without assets - depreciation opportunity";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "Your business has significant revenue. Have you considered purchasing depreciable assets (computers, machinery, office equipment) for tax benefits under depreciation provisions?",
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (profile.dependents && profile.dependents.length > 0) {
      const minorDependents = profile.dependents.filter(d => d.age < 18);
      const adultDependents = profile.dependents.filter(d => d.age >= 18);
      
      if (minorDependents.length > 0) {
        const context = "Minor dependents - clubbing provision awareness";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "You have minor dependents. Are you aware of the clubbing provisions and tax implications of income in their names?",
            context: context,
            priority: priority--
          });
        }
      }
      
      if (adultDependents.length > 0 && totalIncome > 1000000) {
        const context = "Adult children - gift provision opportunity";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: `You have ${adultDependents.length} adult dependent(s). Have you considered gifting income-generating assets to them to utilize their basic exemption limit of ₹2.5 lakh each? The income from gifted assets won't be clubbed in your hands.`,
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (totalIncome > 500000) {
      const deductibleExpenses = expenses.filter(e => e.isEligibleForDeduction);
      const total80C = deductibleExpenses
        .filter(e => e.type.includes("80C"))
        .reduce((sum, e) => sum + parseFloat(e.amount), 0);
      
      if (total80C < 150000) {
        const context = "Section 80C underutilization";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: `You have utilized ₹${total80C.toFixed(0)} out of ₹1,50,000 under Section 80C. Would you like to maximize this deduction through PPF, ELSS, or other eligible investments?`,
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (profile.incomeBreakdown.salary && profile.incomeBreakdown.salary > 0) {
      const hraExpenses = expenses.filter(e => e.type.toLowerCase().includes("hra") || e.type.toLowerCase().includes("rent"));
      if (hraExpenses.length === 0) {
        const context = "Salaried employee - potential HRA exemption";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "Are you paying rent for your residence? If yes, you may be eligible for HRA exemption under Section 10(13A).",
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (assets.length > 0) {
      const oldAssets = assets.filter(a => {
        const purchaseDate = new Date(a.purchaseDate);
        const yearsSincePurchase = (Date.now() - purchaseDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
        return yearsSincePurchase > 2;
      });
      
      if (oldAssets.length > 0) {
        const context = "Long-term assets - LTCG awareness";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "You have assets held for more than 2 years. Are you aware of the long-term capital gains tax implications and indexation benefits if you sell them?",
            context: context,
            priority: priority--
          });
        }
      }
      
      const interestBearingAssets = assets.filter(a => 
        a.type.toLowerCase().includes("fd") || 
        a.type.toLowerCase().includes("deposit") || 
        a.type.toLowerCase().includes("bond")
      );
      
      if (interestBearingAssets.length > 0 && businessDetails && businessDetails.revenue) {
        const context = "Interest income - business expense opportunity";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "You have interest-bearing assets and run a business. Consider converting some personal investments into business-related investments if they serve a business purpose. Interest income can sometimes be offset against business expenses if properly structured and documented.",
            context: context,
            priority: priority--
          });
        }
      }
      
      if (profile.spouseInfo && !profile.spouseInfo.hasIncome && businessDetails) {
        const context = "Spouse employment - salary deduction";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: "Your spouse currently has no income, and you run a business. If your spouse actually works in the business (bookkeeping, administration, marketing, etc.), you can pay them a reasonable salary. This salary is a business expense for you and taxable income for them - potentially utilizing their ₹2.5 lakh basic exemption. Ensure genuine work and proper documentation.",
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (totalIncome > 500000) {
      const npsExpenses = expenses.filter(e => 
        e.type.toLowerCase().includes("nps") || 
        e.type.toLowerCase().includes("80ccd")
      );
      const npsAmount = npsExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);
      
      if (npsAmount < 50000) {
        const context = "NPS additional deduction opportunity";
        if (shouldAddQuestion(context)) {
          questions.push({
            profileId: profileId,
            question: `Additional deduction of ₹50,000 is available under Section 80CCD(1B) for NPS contributions, over and above the ₹1.5 lakh limit of Section 80C. You've invested ₹${npsAmount.toFixed(0)} so far. Would you like to maximize this benefit?`,
            context: context,
            priority: priority--
          });
        }
      }
    }

    if (totalIncome > 1500000 && profile.dependents && profile.dependents.length > 2) {
      const context = "HUF formation opportunity";
      if (shouldAddQuestion(context)) {
        questions.push({
          profileId: profileId,
          question: "Given your income level and family size, have you considered forming a Hindu Undivided Family (HUF)? An HUF can have its own PAN, file separate returns, and claim an additional ₹2.5 lakh basic exemption plus all deductions under Chapter VI-A. This can provide significant tax savings through legal income splitting.",
          context: context,
          priority: priority--
        });
      }
    }

    const createdQuestions: FollowupQuestion[] = [];
    for (const question of questions) {
      const created = await storage.createFollowupQuestion(question);
      createdQuestions.push(created);
    }

    console.log(`Created ${createdQuestions.length} new questions for profile ${profileId}`);
    
    const allQuestions = [...existingQuestions, ...createdQuestions];
    return allQuestions.sort((a, b) => (b.priority || 0) - (a.priority || 0));

  } catch (error) {
    console.error("Error generating proactive questions:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error details:", errorMessage);
    
    const existingQuestions = await storage.getFollowupQuestionsByProfileId(profileId);
    if (existingQuestions.length > 0) {
      console.log(`Returning ${existingQuestions.length} existing questions due to error`);
      return existingQuestions;
    }
    
    return [];
  }
}

export async function analyzeStrategyWithGemini(
  profile: FinancialProfile,
  actSections: SearchResult[]
): Promise<StrategyAnalysis> {
  if (!ai) {
    const errorMsg = "Gemini AI not initialized - API key may be missing";
    console.error(errorMsg);
    throw new Error(errorMsg);
  }

  try {
    const context = actSections.slice(0, 10).map(section => 
      `Section ${section.sectionNumber}: ${section.sectionTitle}\n${section.content}`
    ).join('\n\n---\n\n');

    const profileSummary = {
      taxpayer: profile.taxpayerInfo,
      spouse: profile.spouseInfo,
      dependents: profile.dependents,
      totalIncome: parseFloat(profile.totalIncome),
      incomeBreakdown: profile.incomeBreakdown
    };

    const systemPrompt = `You are an expert Chartered Accountant with deep knowledge of the Indian Income Tax Act, 1961. 
Think like a seasoned CA who proactively identifies tax-saving opportunities by analyzing the client's complete financial situation.

Your CA mindset involves:
- Looking for opportunities to distribute income within the family to utilize multiple basic exemption limits
- Identifying assets that could be transferred through gift provisions to reduce overall family tax burden
- Understanding clubbing provisions and how to legally avoid them
- Spotting underutilized deductions and exemptions
- Recommending restructuring strategies before the financial year ends
- Being aware of HUF (Hindu Undivided Family) benefits where applicable
- Considering timing strategies for income recognition and expense claims

Analyze the financial profile and Act sections to identify ALL applicable strategies:

1. FAMILY TAX OPTIMIZATION:
   - Gift provisions (Section 56, 64): 
     * Transfer of assets to spouse: Income WILL be clubbed under Section 64(1)(iv)
     * Transfer to adult children (18+): Income NOT clubbed - only minor children subject to clubbing under Section 64(1A)
     * Utilize adult children's basic exemption (₹2.5 lakh each) by gifting income-generating assets to them
   - Legitimate spousal employment: If spouse works in business, pay reasonable salary (business expense + utilizes their exemption)
   - Adult children's basic exemption limit utilization (₹2.5 lakh each) - income NOT clubbed after age 18
   - HUF (Hindu Undivided Family): Separate PAN, separate ₹2.5 lakh exemption, eligible for all Chapter VI-A deductions

2. BUSINESS & PROFESSIONAL INCOME:
   - Depreciation optimization (Section 32): Purchase assets before year-end for full depreciation
   - Business restructuring: Salary to family members employed in business
   - Professional expense maximization while staying compliant

3. DEDUCTIONS & EXEMPTIONS:
   - Section 80C optimization (₹1.5 lakh): PPF, ELSS, Life Insurance, Tuition fees
   - Section 80D (Health insurance): ₹25,000 (₹50,000 for senior citizens)
   - Section 80CCD(1B): Additional ₹50,000 NPS deduction
   - HRA exemption optimization (Section 10(13A))
   - LTA (Leave Travel Allowance) planning

4. INVESTMENT STRATEGIES:
   - Long-term vs short-term capital gains planning
   - Tax-free income sources: Agricultural income, municipal bonds
   - Indexation benefits on long-term assets

For EACH strategy:
- Calculate realistic tax savings based on marginal tax rate
- Assess feasibility given current profile (confidence 0.0-1.0)
- Cite exact Income Tax Act section numbers
- Provide step-by-step implementation actions
- Warn about clubbing or anti-avoidance provisions if applicable

Be detailed, practical, and legally compliant. Prioritize strategies with highest savings potential and feasibility.`;

    const userPrompt = `Financial Profile:
${JSON.stringify(profileSummary, null, 2)}

Relevant Income Tax Act Sections:
${context}

Analyze this profile and identify all applicable tax-saving strategies. For each strategy:
- Explain what it is and why it applies
- Estimate the potential tax saving in rupees
- Provide a confidence score (0.0-1.0)
- Cite the relevant Income Tax Act sections
- List specific actions required

Respond with comprehensive tax optimization strategies based solely on the provided Act sections.`;

    console.log("Calling Gemini API for strategy analysis...");
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            strategies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: {
                    type: "string",
                    description: "Strategy type (e.g., 'Income Splitting', 'Depreciation Optimization')"
                  },
                  description: {
                    type: "string",
                    description: "Detailed description of the strategy"
                  },
                  potentialSaving: {
                    type: "number",
                    description: "Estimated tax saving in rupees"
                  },
                  confidence: {
                    type: "number",
                    description: "Confidence score between 0.0 and 1.0"
                  },
                  statutoryRefs: {
                    type: "array",
                    items: { type: "string" },
                    description: "Income Tax Act section references"
                  },
                  requiredActions: {
                    type: "array",
                    items: { type: "string" },
                    description: "Specific actions the taxpayer should take"
                  }
                },
                required: ["type", "description", "potentialSaving", "confidence", "statutoryRefs", "requiredActions"]
              }
            },
            totalPotentialSaving: {
              type: "number",
              description: "Total potential tax saving across all strategies"
            },
            summary: {
              type: "string",
              description: "Brief summary of the overall tax strategy recommendation"
            }
          },
          required: ["strategies", "totalPotentialSaving", "summary"]
        }
      },
      contents: userPrompt
    });

    const rawJson = response.text;
    
    if (!rawJson || rawJson.trim() === "") {
      console.error("Gemini returned empty response");
      throw new Error("Empty response from Gemini API");
    }

    console.log("Gemini response received, parsing JSON...");
    
    let analysis: StrategyAnalysis;
    try {
      analysis = JSON.parse(rawJson);
    } catch (parseError) {
      console.error("JSON parse error:", parseError);
      console.error("Raw response:", rawJson.substring(0, 500));
      
      const jsonMatch = rawJson.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        console.log("Attempting fallback JSON extraction...");
        try {
          analysis = JSON.parse(jsonMatch[0]);
        } catch (fallbackError) {
          console.error("Fallback JSON parse also failed:", fallbackError);
          throw new Error("Failed to parse Gemini response as JSON");
        }
      } else {
        throw new Error("No JSON object found in Gemini response");
      }
    }

    if (!analysis.strategies || !Array.isArray(analysis.strategies)) {
      console.error("Invalid response structure - missing or invalid strategies array");
      throw new Error("Invalid response structure from Gemini");
    }

    console.log(`Strategy analysis complete: ${analysis.strategies.length} strategies identified`);
    return analysis;

  } catch (error) {
    console.error("Strategy analysis with Gemini failed:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    console.error("Error details:", errorMessage);
    
    throw error;
  }
}

export async function getRelevantActSections(
  profile: FinancialProfile,
  storage: IStorage
): Promise<SearchResult[]> {
  try {
    const keywords: string[] = [];

    if (profile.spouseInfo) {
      keywords.push("gift", "spouse", "transfer", "clubbing", "section 64");
      if (!profile.spouseInfo.hasIncome) {
        keywords.push("income splitting", "basic exemption");
      }
    }

    if (profile.dependents && profile.dependents.length > 0) {
      keywords.push("dependent", "family", "minor", "clubbing provisions");
    }

    if (profile.incomeBreakdown.salary && profile.incomeBreakdown.salary > 0) {
      keywords.push("salary", "HRA", "house rent allowance", "section 10", "exemption", "standard deduction");
    }

    if (profile.incomeBreakdown.business && profile.incomeBreakdown.business > 0) {
      keywords.push("business", "depreciation", "section 32", "assets", "business expenses", "presumptive taxation");
    }

    if (profile.incomeBreakdown.capitalGains && profile.incomeBreakdown.capitalGains > 0) {
      keywords.push("capital gains", "LTCG", "STCG", "indexation", "exemption");
    }

    if (profile.incomeBreakdown.rental && profile.incomeBreakdown.rental > 0) {
      keywords.push("rental income", "house property", "section 24", "interest on loan");
    }

    keywords.push("deduction", "80C", "80D", "80E", "chapter VI-A");
    keywords.push("tax saving", "exemption", "rebate");

    const totalIncome = parseFloat(profile.totalIncome);
    if (totalIncome > 1000000) {
      keywords.push("surcharge", "tax planning", "investment");
    }

    const uniqueKeywords = Array.from(new Set(keywords));
    
    const searchResults = await storage.searchDocumentSections(uniqueKeywords);
    
    return searchResults.slice(0, 15);

  } catch (error) {
    console.error("Error getting relevant Act sections:", error);
    return [];
  }
}
