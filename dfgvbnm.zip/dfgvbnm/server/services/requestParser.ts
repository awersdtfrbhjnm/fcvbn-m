import { extractKeywords, type KeywordExtractionResult } from './gemini';

export interface ParsedUserRequest {
  originalQuery: string;
  keywords: string[];
  intent: string;
  confidence: number;
  queryType: QueryType;
  sectionNumbers: string[];
  entities: TaxEntity[];
}

export enum QueryType {
  SECTION_LOOKUP = 'section_lookup',
  GENERAL_QUERY = 'general_query',
  CALCULATION = 'calculation',
  DEDUCTION = 'deduction',
  TDS = 'tds',
  EXEMPTION = 'exemption',
  COMPLIANCE = 'compliance'
}

export interface TaxEntity {
  type: 'section' | 'amount' | 'percentage' | 'date' | 'form' | 'category';
  value: string;
  confidence: number;
}

export async function parseUserRequest(userQuery: string): Promise<ParsedUserRequest> {
  try {
    // Extract keywords using Gemini AI
    const keywordResult: KeywordExtractionResult = await extractKeywords(userQuery);
    
    // Extract section numbers
    const sectionNumbers = extractSectionNumbers(userQuery);
    
    // Determine query type
    const queryType = determineQueryType(userQuery, keywordResult.keywords);
    
    // Extract tax entities
    const entities = extractTaxEntities(userQuery);
    
    // Enhance keywords with domain-specific terms
    const enhancedKeywords = enhanceKeywords(keywordResult.keywords, queryType, entities);
    
    return {
      originalQuery: userQuery,
      keywords: enhancedKeywords,
      intent: keywordResult.intent,
      confidence: keywordResult.confidence,
      queryType,
      sectionNumbers,
      entities
    };
  } catch (error) {
    console.error('Request parsing error:', error);
    
    // Fallback parsing logic
    return fallbackParseRequest(userQuery);
  }
}

function extractSectionNumbers(query: string): string[] {
  const sectionPatterns = [
    /section\s+(\d+[a-z]?)/gi,
    /sec\s+(\d+[a-z]?)/gi,
    /\b(\d+[a-z]?)\s*(?:of|under)/gi,
    /\b(\d{1,3}[a-z]?)\b/g
  ];
  
  const sections: string[] = [];
  
  for (const pattern of sectionPatterns) {
    const matches = Array.from(query.matchAll(pattern));
    for (const match of matches) {
      const section = match[1].toUpperCase();
      if (!sections.includes(section) && isValidSectionNumber(section)) {
        sections.push(section);
      }
    }
  }
  
  return sections;
}

function isValidSectionNumber(section: string): boolean {
  // Valid section numbers are typically 1-3 digits with optional letter
  return /^\d{1,3}[A-Z]?$/.test(section);
}

function determineQueryType(query: string, keywords: string[]): QueryType {
  const lowercaseQuery = query.toLowerCase();
  
  // Section lookup patterns
  if (query.match(/section\s+\d+/i) || query.match(/explain\s+section/i)) {
    return QueryType.SECTION_LOOKUP;
  }
  
  // TDS patterns
  if (lowercaseQuery.includes('tds') || lowercaseQuery.includes('tax deducted at source') ||
      lowercaseQuery.includes('withholding tax') || keywords.some(k => k.includes('194'))) {
    return QueryType.TDS;
  }
  
  // Deduction patterns
  if (lowercaseQuery.includes('deduction') || lowercaseQuery.includes('80c') ||
      lowercaseQuery.includes('80d') || lowercaseQuery.includes('save tax')) {
    return QueryType.DEDUCTION;
  }
  
  // Exemption patterns
  if (lowercaseQuery.includes('exempt') || lowercaseQuery.includes('free') ||
      lowercaseQuery.includes('not taxable') || keywords.includes('10')) {
    return QueryType.EXEMPTION;
  }
  
  // Calculation patterns
  if (lowercaseQuery.includes('calculate') || lowercaseQuery.includes('computation') ||
      lowercaseQuery.includes('how much tax') || lowercaseQuery.includes('tax liability')) {
    return QueryType.CALCULATION;
  }
  
  // Compliance patterns
  if (lowercaseQuery.includes('filing') || lowercaseQuery.includes('return') ||
      lowercaseQuery.includes('compliance') || lowercaseQuery.includes('penalty')) {
    return QueryType.COMPLIANCE;
  }
  
  return QueryType.GENERAL_QUERY;
}

function extractTaxEntities(query: string): TaxEntity[] {
  const entities: TaxEntity[] = [];
  
  // Extract amounts
  const amountPatterns = [
    /(?:rs\.?|rupees?)\s*(\d+(?:,\d+)*(?:\.\d+)?)/gi,
    /(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:rs\.?|rupees?|lakh|crore)/gi,
    /(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:thousand|lakh|crore)/gi
  ];
  
  for (const pattern of amountPatterns) {
    const matches = Array.from(query.matchAll(pattern));
    for (const match of matches) {
      entities.push({
        type: 'amount',
        value: match[1],
        confidence: 0.9
      });
    }
  }
  
  // Extract percentages
  const percentagePattern = /(\d+(?:\.\d+)?)\s*%/g;
  const percentageMatches = Array.from(query.matchAll(percentagePattern));
  for (const match of percentageMatches) {
    entities.push({
      type: 'percentage',
      value: match[1],
      confidence: 0.95
    });
  }
  
  // Extract dates
  const datePatterns = [
    /(\d{1,2}[-/]\d{1,2}[-/]\d{4})/g,
    /(april|march|january|february|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+\d{4}/gi,
    /(financial year|fy)\s*(\d{4}[-]\d{2,4})/gi
  ];
  
  for (const pattern of datePatterns) {
    const matches = Array.from(query.matchAll(pattern));
    for (const match of matches) {
      entities.push({
        type: 'date',
        value: match[1] || match[0],
        confidence: 0.8
      });
    }
  }
  
  // Extract form numbers
  const formPattern = /form\s+(\d+[a-z]?)/gi;
  const formMatches = Array.from(query.matchAll(formPattern));
  for (const match of formMatches) {
    entities.push({
      type: 'form',
      value: match[1].toUpperCase(),
      confidence: 0.9
    });
  }
  
  return entities;
}

function enhanceKeywords(keywords: string[], queryType: QueryType, entities: TaxEntity[]): string[] {
  const enhanced = [...keywords];
  
  // Add query type specific keywords
  switch (queryType) {
    case QueryType.TDS:
      enhanced.push('tax', 'deducted', 'source', 'withholding', 'credit');
      break;
    case QueryType.DEDUCTION:
      enhanced.push('deduction', 'allowable', 'exempt', 'save');
      break;
    case QueryType.EXEMPTION:
      enhanced.push('exempt', 'excluded', 'free', 'relief');
      break;
    case QueryType.CALCULATION:
      enhanced.push('compute', 'calculate', 'liability', 'rate');
      break;
    case QueryType.COMPLIANCE:
      enhanced.push('filing', 'return', 'penalty', 'due');
      break;
  }
  
  // Add entity values as keywords
  for (const entity of entities) {
    if (entity.confidence > 0.7) {
      enhanced.push(entity.value.toLowerCase());
    }
  }
  
  // Remove duplicates and filter
  return Array.from(new Set(enhanced))
    .filter(keyword => keyword.length > 2)
    .slice(0, 15); // Limit to top 15 keywords
}

function fallbackParseRequest(query: string): ParsedUserRequest {
  // Basic keyword extraction
  const words = query.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 2);
  
  const keywords = Array.from(new Set(words)).slice(0, 10);
  const sectionNumbers = extractSectionNumbers(query);
  
  return {
    originalQuery: query,
    keywords,
    intent: 'General tax query',
    confidence: 0.5,
    queryType: QueryType.GENERAL_QUERY,
    sectionNumbers,
    entities: []
  };
}

export function getSearchTerms(parsedRequest: ParsedUserRequest): string[] {
  const searchTerms = [
    ...parsedRequest.keywords,
    ...parsedRequest.sectionNumbers,
    ...parsedRequest.entities.map(e => e.value)
  ];
  
  // Add synonyms based on query type
  switch (parsedRequest.queryType) {
    case QueryType.TDS:
      searchTerms.push('deduction at source', 'withholding', '194');
      break;
    case QueryType.DEDUCTION:
      searchTerms.push('allowable expenses', 'chapter via');
      break;
    case QueryType.EXEMPTION:
      searchTerms.push('income not included', 'section 10');
      break;
  }
  
  return Array.from(new Set(searchTerms.filter(term => term.length > 1)));
}