import { GoogleGenAI } from "@google/genai";
import type { SearchResult, MessageSource } from "@shared/schema";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface KeywordExtractionResult {
  keywords: string[];
  intent: string;
  confidence: number;
}

export interface ResponseGenerationResult {
  response: string;
  sources: MessageSource[];
}

export async function extractKeywords(userQuery: string): Promise<KeywordExtractionResult> {
  try {
    const systemPrompt = `You are a keyword extraction expert for Income Tax Act queries. 
Extract the most relevant keywords and determine the user's intent from their query.
Focus on tax-related terms, section numbers, and legal concepts.
Respond with JSON in this format: 
{
  "keywords": ["keyword1", "keyword2", ...],
  "intent": "brief description of what user wants",
  "confidence": 0.0-1.0
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            keywords: { 
              type: "array",
              items: { type: "string" }
            },
            intent: { type: "string" },
            confidence: { type: "number" }
          },
          required: ["keywords", "intent", "confidence"]
        }
      },
      contents: userQuery
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Keyword extraction failed:", error);
    // Fallback: basic keyword extraction
    const keywords = userQuery.toLowerCase()
      .split(/\s+/)
      .filter(word => word.length > 2)
      .slice(0, 10);
    
    return {
      keywords,
      intent: "General tax query",
      confidence: 0.5
    };
  }
}

export async function generateResponse(
  userQuery: string,
  searchResults: SearchResult[]
): Promise<ResponseGenerationResult> {
  try {
    if (searchResults.length === 0) {
      return {
        response: "I couldn't find any relevant sections in the Income Tax Act for your query. Please try rephrasing your question or use more specific terms.",
        sources: []
      };
    }

    // Prepare context from search results
    const context = searchResults.slice(0, 5).map(result => 
      `Section ${result.sectionNumber}: ${result.sectionTitle}\n${result.content}`
    ).join('\n\n---\n\n');

    const systemPrompt = `You are an expert Income Tax Act assistant. Use ONLY the provided context from the Income Tax Act to answer the user's question. 
Do not add information not present in the context.
Structure your response clearly and reference specific sections.
If the context doesn't contain enough information, say so clearly.
Be precise and cite section numbers when relevant.`;

    const userPrompt = `Context from Income Tax Act:\n${context}\n\nUser Question: ${userQuery}\n\nProvide a comprehensive answer based only on the provided context.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: userPrompt
    });

    const responseText = response.text || "I apologize, but I couldn't generate a response at this time.";

    // Convert search results to message sources
    const sources: MessageSource[] = searchResults.slice(0, 5).map(result => ({
      sectionId: result.sectionId,
      sectionTitle: result.sectionTitle,
      sectionNumber: result.sectionNumber,
      pageNumbers: result.pageNumbers,
      relevanceScore: result.relevanceScore
    }));

    return {
      response: responseText,
      sources
    };

  } catch (error) {
    console.error("Response generation failed:", error);
    return {
      response: "I encountered an error while processing your request. Please try again.",
      sources: []
    };
  }
}
