import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import * as fs from "fs";
import * as path from "path";
import { storage } from "./storage";
import { processTaxActText } from "./services/textProcessor";
import { extractKeywords, generateResponse } from "./services/gemini";
import { parseUserRequest, getSearchTerms } from "./services/requestParser";
import { TAX_ACT_SAMPLE_CONTENT, RECENT_SECTIONS, POPULAR_TOPICS, DOCUMENT_STATS } from "./data/taxActSample";
import { initializeSamplePDFContent, getExpandedTaxActSections } from "./data/samplePDFProcessor";
import { loadFullIncomeTaxActPDF, getDocumentStatus, ensureUploadsDirectory } from "./admin/pdfUploader";
import { chatRequestSchema, insertFinancialProfileSchema, insertIncomeSourceSchema, insertExpenseSchema, insertAssetSchema, insertBusinessDetailsSchema } from "@shared/schema";
import { randomUUID } from "crypto";
import { detectTaxOpportunities, generateProactiveQuestions } from "./services/taxStrategyService";

// Configure multer for admin PDF uploads
const uploadsDir = ensureUploadsDirectory();
const upload = multer({
  dest: uploadsDir,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  },
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB limit for full Act PDF
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Initialize sample data
  await initializeSampleData();

  // Admin endpoint to upload complete Income Tax Act PDF
  app.post("/api/admin/upload-full-pdf", upload.single('pdf'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No PDF file uploaded" });
      }

      console.log(`Processing complete Income Tax Act PDF: ${req.file.originalname} (${(req.file.size / 1024 / 1024).toFixed(2)} MB)`);
      
      const result = await loadFullIncomeTaxActPDF(req.file.path);
      
      // Clean up uploaded file
      fs.unlinkSync(req.file.path);
      
      if (result.success) {
        res.json({
          message: result.message,
          sectionsCount: result.sectionsCount,
          totalPages: result.totalPages,
          filename: req.file.originalname
        });
      } else {
        res.status(400).json({ message: result.message });
      }

    } catch (error) {
      console.error("Full PDF upload error:", error);
      
      // Clean up file if it exists
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      
      res.status(500).json({ 
        message: "Failed to process complete PDF",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Admin endpoint to check document status
  app.get("/api/admin/document-status", async (req, res) => {
    try {
      const status = await getDocumentStatus();
      res.json(status);
    } catch (error) {
      console.error("Document status error:", error);
      res.status(500).json({ message: "Failed to get document status" });
    }
  });



  // Chat endpoint with enhanced parsing and tax planning integration
  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = chatRequestSchema.parse(req.body);
      const { message, sessionId, userId } = validatedData;

      // Store user message
      await storage.createChatMessage({
        sessionId,
        userId: userId || "anonymous",
        content: message,
        role: "user",
        sources: []
      });

      // Check if user has a financial profile
      let financialProfile = null;
      let strategies: any[] = [];
      let followupQuestions: any[] = [];
      
      if (userId && userId !== "anonymous") {
        financialProfile = await storage.getFinancialProfileByUserId(userId);
      }

      // Parse user request with enhanced logic
      const parsedRequest = await parseUserRequest(message);
      console.log('Parsed request:', parsedRequest);
      
      // Get enhanced search terms
      const searchTerms = getSearchTerms(parsedRequest);
      
      // Search for relevant sections using enhanced terms
      const searchResults = await storage.searchDocumentSections(searchTerms);

      // If user has a profile, detect strategies and generate questions
      if (financialProfile) {
        console.log(`User has financial profile: ${financialProfile.id}`);
        
        try {
          // Detect tax opportunities based on profile
          strategies = await detectTaxOpportunities(financialProfile.id, storage);
          
          // Generate proactive questions to complete profile or optimize further
          followupQuestions = await generateProactiveQuestions(financialProfile.id, storage);
          
          console.log(`Detected ${strategies.length} strategies and ${followupQuestions.length} questions`);
        } catch (error) {
          console.error("Error detecting strategies/questions:", error);
        }
      }

      // Generate response using Gemini with found sections
      // Enhance prompt if user has a profile
      let enhancedMessage = message;
      if (financialProfile) {
        const profileSummary = `User's Profile: ${financialProfile.taxpayerInfo.name}, Age ${financialProfile.taxpayerInfo.age}, Total Income: ₹${parseFloat(financialProfile.totalIncome).toLocaleString('en-IN')}`;
        enhancedMessage = `${profileSummary}\n\nUser Question: ${message}\n\nProvide personalized advice based on their financial profile.`;
      }
      
      const responseResult = await generateResponse(enhancedMessage, searchResults);

      // Store assistant message
      const assistantMessage = await storage.createChatMessage({
        sessionId,
        userId: userId || "anonymous",
        content: responseResult.response,
        role: "assistant", 
        sources: responseResult.sources
      });

      const chatResponse = {
        id: assistantMessage.id,
        content: responseResult.response,
        sources: responseResult.sources,
        processing: false,
        hasFinancialProfile: !!financialProfile,
        strategies: strategies.length > 0 ? strategies : undefined,
        followupQuestions: followupQuestions.length > 0 ? followupQuestions : undefined,
        parsedQuery: {
          intent: parsedRequest.intent,
          queryType: parsedRequest.queryType,
          confidence: parsedRequest.confidence
        }
      };

      console.log('Chat Response Structure:', {
        id: chatResponse.id,
        hasFinancialProfile: chatResponse.hasFinancialProfile,
        strategiesCount: strategies.length,
        strategiesIncluded: !!chatResponse.strategies,
        followupQuestionsCount: followupQuestions.length,
        followupQuestionsIncluded: !!chatResponse.followupQuestions,
        sourcesCount: chatResponse.sources.length
      });

      res.json(chatResponse);

    } catch (error) {
      console.error("Chat endpoint error:", error);
      res.status(500).json({ 
        message: "Failed to process chat request",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get chat history
  app.get("/api/chat/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessagesBySession(sessionId);
      res.json(messages);
    } catch (error) {
      console.error("Get chat history error:", error);
      res.status(500).json({ message: "Failed to retrieve chat history" });
    }
  });

  // Search endpoint for document sections
  app.get("/api/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }

      const results = await storage.searchContent(q);
      res.json(results);
    } catch (error) {
      console.error("Search endpoint error:", error);
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Get app data (recent sections, topics, stats)
  app.get("/api/app-data", async (req, res) => {
    try {
      res.json({
        recentSections: RECENT_SECTIONS,
        popularTopics: POPULAR_TOPICS,
        stats: DOCUMENT_STATS
      });
    } catch (error) {
      console.error("App data endpoint error:", error);
      res.status(500).json({ message: "Failed to load app data" });
    }
  });

  // Get all documents
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getAllDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Documents endpoint error:", error);
      res.status(500).json({ message: "Failed to retrieve documents" });
    }
  });

  // Financial Profile endpoints
  app.post("/api/financial-profile", async (req, res) => {
    try {
      const { 
        userId, 
        taxpayerInfo, 
        spouseInfo, 
        dependents, 
        incomeSources, 
        expenses, 
        assets, 
        businessDetails 
      } = req.body;

      let totalIncome = 0;
      const incomeBreakdown: any = {
        salary: 0,
        business: 0,
        capitalGains: 0,
        rental: 0,
        other: 0
      };

      for (const source of incomeSources || []) {
        const amount = parseFloat(source.amount);
        totalIncome += amount;
        
        const type = source.type.toLowerCase();
        if (type.includes('salary')) incomeBreakdown.salary += amount;
        else if (type.includes('business')) incomeBreakdown.business += amount;
        else if (type.includes('capital')) incomeBreakdown.capitalGains += amount;
        else if (type.includes('rental')) incomeBreakdown.rental += amount;
        else incomeBreakdown.other += amount;
      }

      const profile = await storage.createFinancialProfile({
        userId,
        taxpayerInfo,
        spouseInfo: spouseInfo || null,
        dependents: dependents || [],
        totalIncome: totalIncome.toString(),
        incomeBreakdown
      });

      for (const source of incomeSources || []) {
        await storage.createIncomeSource({
          profileId: profile.id,
          type: source.type,
          amount: source.amount,
          details: source.details || null
        });
      }

      for (const expense of expenses || []) {
        await storage.createExpense({
          profileId: profile.id,
          type: expense.type,
          amount: expense.amount,
          isEligibleForDeduction: expense.isEligibleForDeduction || false,
          details: expense.details || null
        });
      }

      for (const asset of assets || []) {
        await storage.createAsset({
          profileId: profile.id,
          type: asset.type,
          purchaseValue: asset.purchaseValue,
          currentValue: asset.currentValue,
          depreciationRate: asset.depreciationRate || null,
          purchaseDate: new Date(asset.purchaseDate)
        });
      }

      if (businessDetails) {
        await storage.createBusinessDetails({
          profileId: profile.id,
          businessType: businessDetails.businessType,
          revenue: businessDetails.revenue,
          hasAssets: businessDetails.hasAssets || false,
          profitMargin: businessDetails.profitMargin || null
        });
      }

      const strategies = await detectTaxOpportunities(profile.id, storage);
      const questions = await generateProactiveQuestions(profile.id, storage);

      res.json({
        profile,
        strategies,
        questions
      });

    } catch (error) {
      console.error("Create financial profile error:", error);
      res.status(500).json({ 
        message: "Failed to create financial profile",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/financial-profile/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const profile = await storage.getFinancialProfileByUserId(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      const incomeSources = await storage.getIncomeSourcesByProfileId(profile.id);
      const expenses = await storage.getExpensesByProfileId(profile.id);
      const assets = await storage.getAssetsByProfileId(profile.id);
      const businessDetails = await storage.getBusinessDetailsByProfileId(profile.id);

      res.json({
        profile,
        incomeSources,
        expenses,
        assets,
        businessDetails
      });

    } catch (error) {
      console.error("Get financial profile error:", error);
      res.status(500).json({ message: "Failed to retrieve financial profile" });
    }
  });

  app.get("/api/tax-strategies/:profileId", async (req, res) => {
    try {
      const { profileId } = req.params;
      const strategies = await storage.getTaxStrategiesByProfileId(profileId);
      res.json(strategies);
    } catch (error) {
      console.error("Get tax strategies error:", error);
      res.status(500).json({ message: "Failed to retrieve tax strategies" });
    }
  });

  app.get("/api/followup-questions/:profileId", async (req, res) => {
    try {
      const { profileId } = req.params;
      const questions = await storage.getFollowupQuestionsByProfileId(profileId);
      res.json(questions);
    } catch (error) {
      console.error("Get followup questions error:", error);
      res.status(500).json({ message: "Failed to retrieve followup questions" });
    }
  });

  app.post("/api/followup-questions/:id/answer", async (req, res) => {
    try {
      const { id } = req.params;
      const { answer } = req.body;

      const question = await storage.getFollowupQuestion(id);
      if (!question) {
        return res.status(404).json({ message: "Followup question not found" });
      }

      const updated = await storage.updateFollowupQuestion(id, {
        answeredAt: new Date() as any
      });

      console.log(`Question ${id} marked as answered at ${new Date().toISOString()}`);

      res.json({
        success: true,
        question: updated,
        message: "Question marked as answered successfully"
      });

    } catch (error) {
      console.error("Mark question as answered error:", error);
      res.status(500).json({ 
        message: "Failed to mark question as answered",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function initializeSampleData() {
  try {
    // Check if documents already exist
    const existingDocs = await storage.getAllDocuments();
    if (existingDocs.length > 0) {
      console.log("Sample data already initialized");
      return;
    }

    // Process pre-loaded PDF content
    const pdfContent = initializeSamplePDFContent();
    const expandedSections = getExpandedTaxActSections();
    
    // Create document in storage
    await storage.createDocument({
      title: "Income Tax Act, 1961",
      content: pdfContent.content,
      sections: expandedSections
    });

    console.log(`Initialized Income Tax Act with ${expandedSections.length} sections from pre-loaded PDF content`);
  } catch (error) {
    console.error("Failed to initialize sample data:", error);
  }
}
