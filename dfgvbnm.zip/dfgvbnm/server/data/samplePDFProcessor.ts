import { processPDFText } from "../services/pdfProcessor";
import type { DocumentSection } from "@shared/schema";

// Sample Income Tax Act content extracted from PDF
// This simulates what would be extracted from a real PDF file
const SAMPLE_PDF_TEXT = `
INCOME TAX ACT, 1961

CHAPTER I
PRELIMINARY

Section 1. Short title, extent and commencement
(1) This Act may be called the Income-tax Act, 1961.
(2) It extends to the whole of India including the State of Jammu and Kashmir.
(3) Save as otherwise provided in this Act, it shall come into force on the 1st day of April, 1962.

Section 2. Definitions
In this Act, unless the context otherwise requires,—
(1) "agricultural income" means—
(a) any rent or revenue derived from land which is situated in India and is used for agricultural purposes;
(b) any income derived from such land by agriculture, or from the performance by a cultivator or receiver of rent-in-kind of any process ordinarily employed by a cultivator or receiver of rent-in-kind to render the produce raised or received by him fit to be taken to market;
(c) any income derived from a farm-house subject to the conditions mentioned in clause (d) of sub-section (3);

CHAPTER III
INCOMES WHICH DO NOT FORM PART OF TOTAL INCOME

Section 10. Incomes not included in total income
The following incomes shall not be included in computing the total income of a previous year:—
(1) Agricultural income as defined in clause (1) of section 2;
(2) Any allowance or perquisite paid or allowed as such outside India by the Government to a citizen of India for rendering service outside India;
(3) Any allowance or perquisite paid or allowed as such outside India by the Government to a citizen of India for rendering service outside India, provided that the allowance or perquisite is paid by the Government of India;

CHAPTER IV
COMPUTATION OF TOTAL INCOME

Section 14. Heads of income
Save as otherwise provided in this Act, all income shall, for the purposes of charge of income-tax and computation of total income, be classified under the following heads:—
(A) Salaries;
(B) Income from house property;
(C) Profits and gains of business or profession;
(D) Capital gains;
(E) Income from other sources.

CHAPTER VI-A
DEDUCTIONS TO BE MADE IN COMPUTING TOTAL INCOME

Section 80C. Deduction in respect of life insurance premia, deferred annuity, provident fund, etc.
(1) In computing the total income of an assessee, being an individual or a Hindu undivided family, there shall be deducted, in accordance with and subject to the provisions of this section, the whole of the amount paid or deposited in the previous year by the assessee—
(a) as life insurance premia to effect or keep in force an insurance on the life of the assessee, or spouse or any child of the assessee;
(b) as a contribution to any provident fund to which the Provident Funds Act, 1925 applies;
(c) as a contribution to an approved superannuation fund;
(d) for participation in the Unit Linked Insurance Plan of the Unit Trust of India established under sub-section (1) of section 3 of the Unit Trust of India Act, 1963;

Section 80D. Deduction in respect of medical insurance premia
(1) In computing the total income of an assessee, being an individual or a Hindu undivided family, there shall be deducted, in accordance with and subject to the provisions of this section, any amount paid by the assessee in the previous year by way of premium to effect or keep in force an insurance on the health of—
(a) the assessee, spouse or dependent children; or
(b) the assessee's parents;

CHAPTER XVII
COLLECTION AND RECOVERY

Section 194. Tax deducted at source
(1) Any person responsible for paying to any resident any income referred to in section 193 shall, at the time of payment of such income, deduct income-tax on the amount payable at the rates in force.
(2) The income-tax shall be deducted only if the amount of such income or, as the case may be, the aggregate of such amounts credited or paid or likely to be credited or paid during the financial year exceeds the minimum amount which is not chargeable to income-tax.

Section 194A. Tax deduction at source on interest other than interest on securities
(1) Any person, not being an individual or a Hindu undivided family, who is responsible for paying to any resident any sum by way of interest other than interest on securities, shall, at the time of credit of such income to the account of the payee or at the time of payment thereof in cash or by issue of a cheque or draft or by any other mode, whichever is earlier, deduct income-tax thereon at the rates in force.

Section 194C. Tax deduction at source on payments to contractors
(1) Any person responsible for paying any sum to any resident (hereinafter referred to as the contractor) for carrying out any work (including supply of labour for carrying out any work) in pursuance of a contract between the contractor and a specified person, shall, at the time of credit of such sum to the account of the contractor or at the time of payment thereof in cash or by issue of a cheque or draft or by any other mode, whichever is earlier, deduct income-tax thereon at the rates in force.
`;

export function initializeSamplePDFContent(): { sections: DocumentSection[]; content: string } {
  console.log('Processing pre-loaded Income Tax Act PDF content...');
  
  const processed = processPDFText(SAMPLE_PDF_TEXT, 50); // Assume 50 pages
  
  console.log(`Initialized Income Tax Act with ${processed.sections.length} sections`);
  
  return {
    sections: processed.sections,
    content: processed.content
  };
}

// Additional function to expand sample content with more realistic sections
export function getExpandedTaxActSections(): DocumentSection[] {
  const baseSections = initializeSamplePDFContent().sections;
  
  // Add more detailed sections for better testing
  const additionalSections: DocumentSection[] = [
    {
      id: "section-80e",
      title: "Deduction in respect of interest on loan taken for higher education",
      sectionNumber: "80E",
      content: "In computing the total income of an assessee, being an individual, there shall be deducted the amount of interest payable by him in the previous year in respect of any loan taken by him from any financial institution or any approved charitable institution for the purpose of pursuing his higher education or higher education of his spouse or children or for whom he is the legal guardian.",
      pageNumbers: [25, 26]
    },
    {
      id: "section-194i",
      title: "Tax deduction at source on rent",
      sectionNumber: "194I",
      content: "Any person, not being an individual or a Hindu undivided family, who is responsible for paying to any resident any income by way of rent exceeding two lakh forty thousand rupees during the financial year, shall, at the time of credit of such income to the account of the payee or at the time of payment thereof in cash or by issue of a cheque or draft or by any other mode, whichever is earlier, deduct income-tax thereon at the rate of ten per cent.",
      pageNumbers: [45, 46]
    },
    {
      id: "section-192",
      title: "Tax deduction at source on salaries",
      sectionNumber: "192",
      content: "Any person responsible for paying any income chargeable under the head 'Salaries' shall, at the time of payment, deduct income-tax on the amount payable at the average rate of income-tax computed on the basis of the rates in force for the financial year in which the payment is made, on the estimated income of the assessee under this head for that financial year.",
      pageNumbers: [43, 44]
    },
    {
      id: "section-87a",
      title: "Rebate of income-tax in case of certain individuals",
      sectionNumber: "87A",
      content: "Where the total income of an assessee, being an individual who is a resident in India, does not exceed five lakh rupees, there shall be allowed a rebate from the amount of income-tax (as computed before allowing for the rebate under this section) on his total income, of an amount equal to one hundred per cent of such income-tax or an amount of twelve thousand five hundred rupees, whichever is less.",
      pageNumbers: [30, 31]
    }
  ];
  
  return [...baseSections, ...additionalSections];
}