// Sample Income Tax Act content for demonstration
// In production, this would be loaded from processed PDF files

export const TAX_ACT_SAMPLE_CONTENT = `Income Tax Act, 1961

Chapter VI-A - Deductions to be made in computing total income

Section 80C: Deduction in respect of life insurance premia, deferred annuity, provident fund, etc.

Subject to the provisions of sub-section (2), there shall be deducted, in computing the total income of an assessee, being an individual or a Hindu undivided family, any sum paid or deposited in the previous year by the assessee:

(a) as life insurance premia to effect or keep in force an insurance on the life of any of the following persons, namely:
(i) the assessee;
(ii) the spouse or the child of the assessee; or
(iii) any other person on whose life the assessee has an insurable interest,
so however that the sum so paid as life insurance premium in any year does not exceed twenty per cent of the actual capital sum assured;

(b) as his contribution to any provident fund set up by the Central Government for the benefit of its employees and to which the Provident Funds Act, 1925 applies, or as his contribution to any recognised provident fund, or as his contribution to any approved superannuation fund;

(c) as his contribution to any pension scheme of the Central Government framed for the benefit of naval, military or air force personnel;

(d) as subscription to any equity oriented fund or equity linked savings scheme referred to in section 10;

(e) for the purchase of any units from the Administrator of the Unit Trust of India established under the Unit Trust of India Act, 1963;

(f) as contribution by way of any sum or sums paid, whether in lump sum or in instalments, for the purchase of units of such Mutual Fund as may be notified by the Central Government in the Official Gazette in this behalf;

(g) for the purchase of any bonds of the National Savings Organisation or deposits with the National Savings Organisation;

(h) as deposit in any account under a scheme framed by the Central Government and notified by the Board in this behalf;

(i) as institutional investment in the form of five-year time deposit in an account designated as Five-year Time Deposit Account for Tax Savings under the Deposit Insurance and Credit Guarantee Corporation Act, 1961, with a banking company to which the Banking Regulation Act, 1949, applies or with a corresponding new bank;

(j) as subscription to the home loan account scheme of the National Housing Bank;

(k) as contribution to any pension fund set up by the Mutual Fund for New Pension System referred to in section 10 as may be notified by the Central Government;

(l) towards payment of tuition fees of any two children of the assessee for full-time education in any university, college, school or other educational institution situated within India;

(m) as principal amount to acquire or construct a residential house property for which a loan is taken from any of the specified sources.

The aggregate amount deductible under all the clauses of this section shall not, in any case, exceed one lakh and fifty thousand rupees.

Section 80D: Deduction in respect of health insurance premia.

Subject to the provisions of sub-section (2), in computing the total income of an assessee, being an individual or a Hindu undivided family, there shall be deducted any sum paid by the assessee in the previous year:

(a) as premium for insurance on the health of the assessee or any member of his family or both;
(b) as premium for insurance on the health of the parents of the assessee.

The deduction under clause (a) shall not exceed twenty-five thousand rupees and the deduction under clause (b) shall not exceed twenty-five thousand rupees.

Where the assessee or his parents are senior citizens, the amount of deduction under clause (a) or clause (b) respectively shall not exceed fifty thousand rupees.

Section 24: Deduction in respect of property income.

Where the property consists of a house, the income from house property shall be computed after making the following deductions, namely:

(a) any municipal taxes paid by the owner during the previous year in respect of the property, and
(b) a sum equal to thirty per cent of the net annual value or, at the option of the assessee, the actual amount expended for the purpose of repairs and collection of rents or both, whichever is less:

Provided that where the amount so expended exceeds the net annual value, the excess shall be ignored.

Where the assessee has taken a loan for the acquisition, construction, repair, renewal or reconstruction of the property, there shall also be deducted the amount of any interest payable on such loan for the previous year:

Provided that where the property is self-occupied, the amount of interest on loan taken for acquisition or construction of the property shall not exceed two lakh rupees.

Section 194A: Tax deducted at source on interest other than interest on securities.

Any person, not being an individual or a Hindu undivided family, who is responsible for paying to a resident any income by way of interest other than interest on securities, shall at the time of credit of such income to the account of the payee or at the time of payment thereof in cash or by issue of a cheque or draft or by any other mode, whichever is earlier, deduct income-tax thereon at the rate of ten per cent.

No deduction shall be made under sub-section (1) if the amount of such income credited or paid or likely to be credited or paid during the financial year does not exceed five thousand rupees.

The provisions of this section shall not apply to the payment of interest on any deposit (other than a time deposit made for a period of less than three months) with a banking company to which the Banking Regulation Act, 1949, applies (including any bank or banking institution referred to in section 51 of that Act), if such interest is paid to:

(a) an individual, if the amount of such interest or, in the aggregate, the amounts of such interest payable to him during the financial year by the banking company do not exceed ten thousand rupees;
(b) a Hindu undivided family, if the amount of such interest or, in the aggregate, the amounts of such interest payable to it during the financial year by the banking company do not exceed ten thousand rupees.

Section 10: Incomes not included in total income.

The following incomes shall not be included in computing the total income:

(1) Agricultural income.
(2) Any sum received under a life insurance policy, including the sum allocated by way of bonus on such policy, other than any sum received under a keyman insurance policy, and any sum received under an insurance policy issued on or after the 1st day of April, 2003 in respect of which the premium payable for any of the years during the term of the policy exceeds twenty per cent of the actual capital sum assured.

(10D) Any sum received under a life insurance policy, including the sum allocated by way of bonus on such policy other than any sum received under a keyman insurance policy, and any sum received under an insurance policy taken on or after the 1st day of April, 2012 in respect of which the premium payable for any of the years during the term of the policy exceeds ten per cent of the actual capital sum assured.

(23C) Any income of a fund or institution or trust or any university or other educational institution or any hospital or other medical institution referred to in sub-section (4) or sub-section (5) of section 35 or of any trust or institution registered under section 12AA.

(38) Any income arising from any award instituted in the public interest by the Government or such other institution, organisation or association as may, having regard to the objects of the award and other relevant considerations, be approved by the Central Government.`;

export const RECENT_SECTIONS = [
  {
    id: "section-80c",
    title: "Deduction in respect of life insurance premia, deferred annuity, provident fund, etc.",
    sectionNumber: "80C",
    description: "Deduction in respect of life insurance premia..."
  },
  {
    id: "section-24",
    title: "Deduction in respect of property income",
    sectionNumber: "24", 
    description: "Deduction in respect of property income..."
  },
  {
    id: "section-194a",
    title: "Tax deducted at source on interest other than interest on securities",
    sectionNumber: "194A",
    description: "Tax deducted at source on interest..."
  }
];

export const POPULAR_TOPICS = [
  "Tax Deductions",
  "TDS", 
  "Capital Gains",
  "House Property",
  "Salary Income"
];

export const DOCUMENT_STATS = {
  totalSections: 298,
  pagesIndexed: 1247
};
