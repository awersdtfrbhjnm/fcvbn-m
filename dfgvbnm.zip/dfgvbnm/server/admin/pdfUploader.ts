import * as fs from 'fs';
import * as path from 'path';
import { processPDFFile, validatePDFContent } from '../services/pdfProcessor';
import { storage } from '../storage';

/**
 * Administrative function to process and load the complete Income Tax Act PDF
 * This should be called once to replace sample content with the full Act
 */
export async function loadFullIncomeTaxActPDF(pdfFilePath: string): Promise<{
  success: boolean;
  message: string;
  sectionsCount?: number;
  totalPages?: number;
}> {
  try {
    console.log(`Starting to process full Income Tax Act PDF from: ${pdfFilePath}`);
    
    // Check if file exists
    if (!fs.existsSync(pdfFilePath)) {
      return {
        success: false,
        message: `PDF file not found at path: ${pdfFilePath}`
      };
    }
    
    // Process the PDF file
    const processedDoc = await processPDFFile(pdfFilePath);
    
    // Validate the processed content
    if (!validatePDFContent(processedDoc.sections)) {
      return {
        success: false,
        message: "The PDF doesn't contain valid Income Tax Act content with sufficient sections"
      };
    }
    
    console.log(`Successfully processed PDF with ${processedDoc.sections.length} sections`);
    
    // Clear any existing documents in storage
    const existingDocs = await storage.getAllDocuments();
    console.log(`Found ${existingDocs.length} existing documents to replace`);
    
    for (const doc of existingDocs) {
      await storage.deleteDocument(doc.id);
      console.log(`Deleted existing document: ${doc.title}`);
    }
    
    // Create the new comprehensive document
    const savedDoc = await storage.createDocument({
      title: "Income Tax Act, 1961 (Complete)",
      content: processedDoc.content,
      sections: processedDoc.sections
    });
    
    console.log(`Successfully loaded complete Income Tax Act with ${processedDoc.sections.length} sections`);
    
    return {
      success: true,
      message: `Successfully processed complete Income Tax Act PDF`,
      sectionsCount: processedDoc.sections.length,
      totalPages: processedDoc.totalPages
    };
    
  } catch (error) {
    console.error('Error processing full Income Tax Act PDF:', error);
    return {
      success: false,
      message: `Failed to process PDF: ${error instanceof Error ? error.message : 'Unknown error'}`
    };
  }
}

/**
 * Function to check current document status
 */
export async function getDocumentStatus(): Promise<{
  documentsCount: number;
  sectionsCount: number;
  documentTitles: string[];
}> {
  try {
    const documents = await storage.getAllDocuments();
    const totalSections = documents.reduce((acc, doc) => acc + doc.sections.length, 0);
    
    return {
      documentsCount: documents.length,
      sectionsCount: totalSections,
      documentTitles: documents.map(doc => doc.title)
    };
  } catch (error) {
    console.error('Error getting document status:', error);
    return {
      documentsCount: 0,
      sectionsCount: 0,
      documentTitles: []
    };
  }
}

/**
 * Utility function to create the uploads directory if it doesn't exist
 */
export function ensureUploadsDirectory(): string {
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
    console.log(`Created uploads directory: ${uploadsDir}`);
  }
  return uploadsDir;
}