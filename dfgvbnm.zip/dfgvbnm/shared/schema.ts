import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json, integer, numeric, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  sections: json("sections").$type<DocumentSection[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: text("session_id").notNull(),
  userId: text("user_id").default("anonymous"),
  content: text("content").notNull(),
  role: text("role").notNull(), // 'user' | 'assistant'
  sources: json("sources").$type<MessageSource[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const searchResults = pgTable("search_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  query: text("query").notNull(),
  results: json("results").$type<SearchResult[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const financialProfiles = pgTable("financial_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  taxpayerInfo: json("taxpayer_info").$type<TaxpayerInfo>().notNull(),
  spouseInfo: json("spouse_info").$type<SpouseInfo>(),
  dependents: json("dependents").$type<Dependent[]>().default([]),
  totalIncome: numeric("total_income").notNull(),
  incomeBreakdown: json("income_breakdown").$type<IncomeBreakdown>().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const incomeSource = pgTable("income_source", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  type: text("type").notNull(),
  amount: numeric("amount").notNull(),
  details: json("details").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  type: text("type").notNull(),
  amount: numeric("amount").notNull(),
  isEligibleForDeduction: boolean("is_eligible_for_deduction").default(false),
  details: json("details").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const assets = pgTable("assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  type: text("type").notNull(),
  purchaseValue: numeric("purchase_value").notNull(),
  currentValue: numeric("current_value").notNull(),
  depreciationRate: numeric("depreciation_rate"),
  purchaseDate: timestamp("purchase_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const businessDetails = pgTable("business_details", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  businessType: text("business_type").notNull(),
  revenue: numeric("revenue").notNull(),
  hasAssets: boolean("has_assets").default(false),
  profitMargin: numeric("profit_margin"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const taxStrategies = pgTable("tax_strategies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  strategyType: text("strategy_type").notNull(),
  description: text("description").notNull(),
  potentialSaving: numeric("potential_saving").notNull(),
  confidence: numeric("confidence").notNull(),
  statutoryRefs: text("statutory_refs").array().default([]),
  requiredActions: text("required_actions").array().default([]),
  status: text("status").notNull().default("pending"),
  detectedAt: timestamp("detected_at").defaultNow(),
});

export const followupQuestions = pgTable("followup_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  question: text("question").notNull(),
  context: text("context"),
  priority: integer("priority").default(0),
  askedAt: timestamp("asked_at").defaultNow(),
  answeredAt: timestamp("answered_at"),
});

// Types
export interface TaxpayerInfo {
  name: string;
  pan: string;
  age: number;
}

export interface SpouseInfo {
  name: string;
  hasIncome: boolean;
  income?: number;
}

export interface Dependent {
  name: string;
  age: number;
  relationship: string;
}

export interface IncomeBreakdown {
  salary?: number;
  business?: number;
  capitalGains?: number;
  rental?: number;
  other?: number;
}

export interface DocumentSection {
  id: string;
  title: string;
  content: string;
  sectionNumber: string;
  pageNumbers: number[];
}

export interface MessageSource {
  sectionId: string;
  sectionTitle: string;
  sectionNumber: string;
  pageNumbers: number[];
  relevanceScore: number;
}

export interface SearchResult {
  sectionId: string;
  sectionTitle: string;
  sectionNumber: string;
  content: string;
  pageNumbers: number[];
  relevanceScore: number;
}

export interface ChatRequest {
  message: string;
  sessionId: string;
  userId?: string;
}

export interface ChatResponse {
  id: string;
  content: string;
  sources: MessageSource[];
  processing: boolean;
  strategies?: TaxStrategy[];
  followupQuestions?: FollowupQuestion[];
  hasFinancialProfile: boolean;
}

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  title: true,
  content: true,
  sections: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  sessionId: true,
  userId: true,
  content: true,
  role: true,
  sources: true,
});

export const chatRequestSchema = z.object({
  message: z.string().min(1).max(2000),
  sessionId: z.string().min(1),
  userId: z.string().optional(),
});

export const insertFinancialProfileSchema = createInsertSchema(financialProfiles).omit({
  id: true,
  createdAt: true,
});

export const insertIncomeSourceSchema = createInsertSchema(incomeSource).omit({
  id: true,
  createdAt: true,
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
});

export const insertAssetSchema = createInsertSchema(assets).omit({
  id: true,
  createdAt: true,
});

export const insertBusinessDetailsSchema = createInsertSchema(businessDetails).omit({
  id: true,
  createdAt: true,
});

export const insertTaxStrategySchema = createInsertSchema(taxStrategies).omit({
  id: true,
  detectedAt: true,
});

export const insertFollowupQuestionSchema = createInsertSchema(followupQuestions).omit({
  id: true,
  askedAt: true,
});

// Inferred types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type FinancialProfile = typeof financialProfiles.$inferSelect;
export type InsertFinancialProfile = z.infer<typeof insertFinancialProfileSchema>;
export type IncomeSource = typeof incomeSource.$inferSelect;
export type InsertIncomeSource = z.infer<typeof insertIncomeSourceSchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type BusinessDetails = typeof businessDetails.$inferSelect;
export type InsertBusinessDetails = z.infer<typeof insertBusinessDetailsSchema>;
export type TaxStrategy = typeof taxStrategies.$inferSelect;
export type InsertTaxStrategy = z.infer<typeof insertTaxStrategySchema>;
export type FollowupQuestion = typeof followupQuestions.$inferSelect;
export type InsertFollowupQuestion = z.infer<typeof insertFollowupQuestionSchema>;
