#!/usr/bin/env node

/**
 * Script to upload the complete Income Tax Act PDF to the system
 * Usage: node scripts/uploadPDF.js <path-to-pdf-file>
 */

import fs from 'fs';
import path from 'path';
import FormData from 'form-data';
import fetch from 'node-fetch';

async function uploadPDF(pdfPath) {
  try {
    // Check if file exists
    if (!fs.existsSync(pdfPath)) {
      console.error(`❌ PDF file not found: ${pdfPath}`);
      process.exit(1);
    }

    // Check file size
    const stats = fs.statSync(pdfPath);
    const fileSizeInMB = stats.size / (1024 * 1024);
    console.log(`📄 File size: ${fileSizeInMB.toFixed(2)} MB`);

    if (fileSizeInMB > 100) {
      console.error(`❌ File too large (${fileSizeInMB.toFixed(2)} MB). Maximum size is 100 MB.`);
      process.exit(1);
    }

    // Create form data
    const form = new FormData();
    form.append('pdf', fs.createReadStream(pdfPath));

    console.log(`🚀 Uploading ${path.basename(pdfPath)} to the system...`);

    // Upload to the admin endpoint
    const response = await fetch('http://localhost:5000/api/admin/upload-full-pdf', {
      method: 'POST',
      body: form
    });

    const result = await response.json();

    if (response.ok) {
      console.log(`✅ Success! ${result.message}`);
      console.log(`📊 Processed ${result.sectionsCount} sections from ${result.totalPages} pages`);
      console.log(`📚 File: ${result.filename}`);
    } else {
      console.error(`❌ Upload failed: ${result.message}`);
      process.exit(1);
    }

  } catch (error) {
    console.error(`❌ Error uploading PDF: ${error.message}`);
    process.exit(1);
  }
}

// Get PDF path from command line arguments
const pdfPath = process.argv[2];

if (!pdfPath) {
  console.log(`
📋 Income Tax Act PDF Uploader

Usage: node scripts/uploadPDF.js <path-to-pdf-file>

Example:
  node scripts/uploadPDF.js ./Income_Tax_Act_1961.pdf
  node scripts/uploadPDF.js /path/to/your/income-tax-act.pdf

This script will:
1. Upload your complete Income Tax Act PDF
2. Process all sections automatically 
3. Replace the sample content with your full Act
4. Make all ~350 sections searchable in the chatbot

Make sure your server is running before uploading!
  `);
  process.exit(1);
}

uploadPDF(pdfPath);