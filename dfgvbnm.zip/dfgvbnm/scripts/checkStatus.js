#!/usr/bin/env node

/**
 * Script to check the current document status in the system
 * Usage: node scripts/checkStatus.js
 */

import fetch from 'node-fetch';

async function checkStatus() {
  try {
    console.log('🔍 Checking document status...\n');

    const response = await fetch('http://localhost:5000/api/admin/document-status');
    
    if (!response.ok) {
      console.error(`❌ Failed to get status: ${response.statusText}`);
      process.exit(1);
    }

    const status = await response.json();

    console.log('📊 Current Document Status:');
    console.log('=' * 40);
    console.log(`📚 Total Documents: ${status.documentsCount}`);
    console.log(`📄 Total Sections: ${status.sectionsCount}`);
    console.log('\n📖 Document Titles:');
    
    if (status.documentTitles.length === 0) {
      console.log('  (No documents loaded)');
    } else {
      status.documentTitles.forEach((title, index) => {
        console.log(`  ${index + 1}. ${title}`);
      });
    }

    console.log('\n💡 Tips:');
    if (status.sectionsCount < 100) {
      console.log('  • You appear to have sample content. Upload the full PDF for all ~350 sections.');
      console.log('  • Use: node scripts/uploadPDF.js <path-to-your-pdf>');
    } else {
      console.log('  • Full Income Tax Act appears to be loaded!');
      console.log('  • Users can now query all sections of the Act.');
    }

  } catch (error) {
    console.error(`❌ Error checking status: ${error.message}`);
    
    if (error.code === 'ECONNREFUSED') {
      console.log('\n💡 Make sure your server is running:');
      console.log('  npm run dev');
    }
    
    process.exit(1);
  }
}

checkStatus();